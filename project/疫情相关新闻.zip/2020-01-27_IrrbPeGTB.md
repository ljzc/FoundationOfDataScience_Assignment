<html>
 <body>
  <h1 id="title">
   #山东叫停一切野生动物交易展演##山东叫停一切野生动物交易展演#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2020-01-27
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IrrbPeGTB">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 123
   </li>
   <li id_no="comment_number">
    评论数量： 167
   </li>
   <li id_no="attitude">
    赞： 1238
   </li>
   <li id_no="target">
    疫情相关： True
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【#山东叫停一切野生动物交易展演#[话筒]# 】27日，山东省人民政府新闻发布会：为严密防控新型冠状病毒引发的肺炎疫情进一步蔓延，山东省宣布叫停与野生动物相关一切交易和展演活动
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     下令加强野生动物与活禽交易管理。其中野生动物一律禁止交易，一律禁止进入市场；对于野生动物园、人工繁育场所加强疾病监测，暂停其中的野生动物出售、购买和展演活动，对其中的野生动物立即实施封控隔离措施。（中新）山东叫停野生动物相关一切交易和展演
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
  </div>
 </body>
</html>