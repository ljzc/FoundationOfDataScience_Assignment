<html>
 <body>
  <h1 id="title">
   #新冠肺炎最新动态##新冠肺炎最新动态#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2020-01-24
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IqXbIbGpV">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 22
   </li>
   <li id_no="comment_number">
    评论数量： 99
   </li>
   <li id_no="attitude">
    赞： 512
   </li>
   <li id_no="target">
    疫情相关： True
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :#新冠肺炎最新动态# 【#宁夏累计确诊病例2例#】2020年1月23日0-24时，全区报告新型冠状病毒感染的肺炎新增确诊病例1例，新增疑似病例1例
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     截止1月23日24时，全区累计报告新型冠状病毒感染的肺炎确诊病例2例(重症病例1例)，其中银川市1例、中卫市1例；疑似病例1例。全区新型冠状病毒感染的肺炎疫情通报 @人民网宁夏频道
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     Ariellecter
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 44
     </li>
    </div>
    <p id="comment_content">
     湖北省委书记蒋超良，湖北省长王晓东，武汉市委书记马国强，武汉市长周先旺。疫病过了，再来记录这几个人的职位。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     热搜粉丝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 34
     </li>
    </div>
    <p id="comment_content">
     潜伏期太长了，还不知道有多少感染者，还没发现呢。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-25
    </p>
    <p id="comment_author">
     清毓池子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@NuovoPignone:我大甘肃连哪个市区的都不知道
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-25
    </p>
    <p id="comment_author">
     尓杜
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@差点是个仙女:绝对挺住
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     芳香如故5835714503
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@红河道:用法律严惩不作为的庸官
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     古松伴青稞
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@古松伴青稞:大家一定想办法动员身边人都带好口罩，太重要了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     Kalends-shuang
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@待我温柔w:@银川卫生健康 中卫的管吗？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     Kalends-shuang
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@待我温柔w:@银川卫生健康
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     Kalends-shuang
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@待我温柔w:卧槽
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     忆忆繁
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     宁夏加油～
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     做个积极向上的人丶
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@老店新开404:中国政府
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     手中的红色石头
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     我的天一例重症
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     狗蛋水饺
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@狗蛋水饺:没法报警，不知道他们都是来自哪里！我看他们微博有的从武汉汉口车站出发，网友反映还有乘飞机的。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     狗蛋水饺
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     华图的一百多员工武汉集训42天，封城前已经回全国各地自己的家了。有网友陆续反映朋友圈看到了。而且根据他们的微博来看并未经过检疫而且乘坐公共交通工具。我问是否检疫被他们骂，网友理性询问也会被骂。恳请有关部门能注意一下，李梦娇微博已删，截图在我微博，路过帮顶谢谢🙏
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     波妞aaaaaa
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     我宁夏挺住
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     Burgess佩云
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@待我温柔w:隔离隔离隔离，为什么还从武汉往来跑
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     Mmiaowwwwww
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     武汉加油，人民加油！求政府下文件希望各大旅行社都能停止出行，旅游景点都是人口密集区域，一定要多加防范！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     爱情禅
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     武汉人及接触过武汉人员，暂且停留，也是为了以后走的更远
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     长夜明月光
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     求求了 街上的流浪汉 他们什么都不知道 还没口罩带
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     差点是个仙女
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 10
     </li>
    </div>
    <p id="comment_content">
     卧槽，太可怕了，宁夏给我挺住
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     若樱花草木
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@往事哥哥:山西加一，感觉没什么防护，也不知道是不是因为我们地方小，走在街上没几个戴口罩的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     落玖爱吃糖
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@这里是海棠a:不过都封了也应该挺严重的，就尽量保护好自己吧
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     若樱花草木
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@失落的酱牛肉:我去，今年过年能不搞幺蛾子吗，本来父母就不信我们，新闻再播出来更难劝
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     天蝎望舒0837
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     疫情速报
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     这里是海棠a
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@南风玖汣:可是都不知道病情
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     若樱花草木
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     唉，很多乡下地方不听劝呀
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     aganmkx
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     今天去外面看到一堆鄂A车牌，武汉人咋素质这么高？真的厉害，现在全国就西藏青海还没发现感染，你们赶快开着车去那，非要把全国都感染了你们才开心
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     Fest689
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@aganmkx:你可真牛逼呢？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     aganmkx
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     武汉人咋素质这么高？真的厉害，现在全国就西藏青海还没发现感染，你们赶快开着车去那，非要把全国都感染了你们才开心
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     Fest689
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@aganmkx:你可真有素质
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     Fest689
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@aganmkx:已经举报
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     团子哥哥啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@aganmkx:那就人家素质低了？去你去武汉一个打一城人去，
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     公关东方
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@Ariellecter:应该撒了武汉的领导，不负责任，不公开透明
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     aganmkx
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@团子哥哥啊:全国都被武汉人感染了，不怪他们怪谁？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     奇侠宝5
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     详细一点啊
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     小y不是小歪呀-
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     中宁的怕了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     李大洛
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     武汉有关部门麻烦关心下医护人员的上下班问题，住宿问题。让他们全心全意投入到战斗中。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     kelinda_kou
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     团子哥哥啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@aganmkx:呦呵，就您这素质高，等以后啥事出你们那里了，就不知道你是个啥了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     毛绒刺猬Wannna
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     真的完全没心情过年，只想好好宅在家，每天醒来第一件事就是刷微博看疫情情况，我相信我们国家，政府，可是现实就是还有很多地方宣传不到位，很多人根本就不以为然，还自以为是。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     Yang丶Sunshine
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     这下真的全中国都被传染了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     aganmkx
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@团子哥哥啊:你还给武汉人洗地？不是他们现在能这样过年？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     待我温柔w
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@待我温柔w:图片评论 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     兵企互联
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@往事哥哥:心态放好，不要担心政府不重视
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     待我温柔w
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     我服了 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     aganmkx
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     武汉人能不能别到处跑？唯恐天下不乱？素质真的低。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     晝訫
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     求政府加强实地宣传叭。。。现在是微博一片着急上火，实地一片泰然自若
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     哎呀我想亲亲你
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@往事哥哥:天天都是放鞭炮
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     Asia冲王
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     所有病情公开透明吧！要引起全国人民重视才行啊！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     兵企互联
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     有点像抗日战争时期日本鬼子发动的细菌战！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     绿蛰
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 5
     </li>
    </div>
    <p id="comment_content">
     发短信提醒群众⚠️  公布疫情具体位置⚠️  发短信提醒群众⚠️  公布疫情具体位置⚠️  发短信提醒群众⚠️  公布疫情具体位置⚠️ 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     aganmkx
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     武汉人真的没素质，见一个打一个
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     男人帮一辈子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     真的是
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     团子哥哥啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@aganmkx:别以偏概全
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     摩托老年组刘芳
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     医疗物资紧张，医护人员紧张的情况，且物价猛涨生活物资渐紧，而非疫区则较少存在这个问题，这意味着即使感染，在非武汉隔离区的其他地方可以得到不一定更好，但是一定更宽松的医疗资源，如果无法用充足的医疗资源和稳定的生活物资建立起本地人认同的心理隔离区，建立交通隔离区必会形同虚设
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     多喝养乐多多益善
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     看看安徽看看安徽看看安徽看看安徽
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     红河道哥
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 15
     </li>
    </div>
    <p id="comment_content">
     我他妈现在都想打死这群吃干饭的，12月就发现问题了，没有任何防控措施也没有对市民进行提醒，那种轻描淡写得语气就像是普通的感冒一样，街上就没几个带口罩的，现在突然这么多人，这群湖北领导绝对脱不了干系！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     一颗甜脆大白菜
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 4
     </li>
    </div>
    <p id="comment_content">
     天那。求求了春晚的时候主持人能插播一下新冠疫情吗？父母根本不听话出门不肯戴口罩。求求你了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     七十二岁
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     南昌麻丘
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     团子哥哥啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@aganmkx:你就那么有素质？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     Clrove·7
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     ………
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     月啊是故乡明
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     多宣传啊啊啊啊！能不能在今晚的春晚抽空挤出时间宣传一下！年纪大的老人根本不知道这次疫情有多严重！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     秦时为你痴狂
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     疫情已经在全国扩散了，建议暂停所有大型公共活动，所有人员出门都要戴口罩，公共场所（特别是车站、机场、港口）的公私职人员也要戴，对所有进出武汉的人员进行隔离观察(如果政府没办法进行单对单隔离，请大家自行隔离)
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     古松伴青稞
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 9
     </li>
    </div>
    <p id="comment_content">
     赶紧重视，今天家人还的去拜年！！让戴口罩都不听
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     落玖爱吃糖
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     回复@Ariellecter:我家这边已经封城了，，我咸宁的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     猩猩pds123
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     千万别不当回事，也别太当回事！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     改过自新学男德
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     吃野味的，把全国害惨了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     孤峰弯月
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 13
     </li>
    </div>
    <p id="comment_content">
     医护人员防护用具医护人员防护用具医护人员防护用具医护人员防护用具医护人员防护用具医护人员防护用具医护人员防护用具医护人员防护用具医护人员防护用具医护人员防护用具医护人员防护用具医护人员防护用具医护人员防护用具医护人员防护用具医护人员防护用具医护人员防护用具医护人员防护用具
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     阿婷说的在理
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     求求都别乱跑了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     aganmkx
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     武汉人是真的没素质，见一个打一个
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     龟龟丞相
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 4
     </li>
    </div>
    <p id="comment_content">
     荆门掇刀二十余人围殴，私自监禁，逼迫医生下跪不属于黑恶势力？罚款五百了事？@最高人民检察院 @人民日报 @紫光阁 @央视新闻
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     今年也要快乐一整年
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     疫情通报的速度及时吗？？为什么我们这种小地方已经确诊的还没有通报？？？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     LaMengi
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 6
     </li>
    </div>
    <p id="comment_content">
     大家多给中老年人宣传一下，特别是小地方 现在好多中老年都不相信疫情的严重性！很多人都不知道情况，跟他们普及也听不进去，觉得小题大做，电视多做普及，村里、小区大喇叭也要不停播放相关病情防控等事宜，此又逢春运，人流密集，再不重视，不提前预防，更是让人担忧 不乱跑 保护他人更是保护自己
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     蛮_不讲理
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     唉。在家保平安
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     右边坐着个神经病啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     回复@Ariellecter:接个楼，希望大家在关注武汉的时候也关注一下湖北其他城市
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     容易__Easy
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     @容易__Easy：#建议全国取消旅行团# 年后想带家人去东北滑雪，可最近越看越不对劲，连东北都有感染病毒的案例了，也有死亡案例了，好怕！可旅行社还是不退钱！！！！！！要扣一大半
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     aganmkx
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     武汉人能不能有点素质？我真的服了！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     热搜粉丝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 34
     </li>
    </div>
    <p id="comment_content">
     潜伏期太长了，还不知道有多少感染者，还没发现呢。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     做个积极向上的人丶
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 4
     </li>
    </div>
    <p id="comment_content">
     美帝就想看你们乱！！信政府！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-24
    </p>
    <p id="comment_author">
     Ariellecter
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 44
     </li>
    </div>
    <p id="comment_content">
     湖北省委书记蒋超良，湖北省长王晓东，武汉市委书记马国强，武汉市长周先旺。疫病过了，再来记录这几个人的职位。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>