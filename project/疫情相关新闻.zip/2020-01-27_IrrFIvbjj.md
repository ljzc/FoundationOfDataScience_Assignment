<html>
 <body>
  <h1 id="title">
   #万众一心抗击疫情##万众一心抗击疫情#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2020-01-27
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IrrFIvbjj">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 109
   </li>
   <li id_no="comment_number">
    评论数量： 112
   </li>
   <li id_no="attitude">
    赞： 571
   </li>
   <li id_no="target">
    疫情相关： True
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :#万众一心抗击疫情#【习近平：紧紧依靠人民群众坚决打赢疫情防控阻击战】习近平作出重要指示，要求各级党组织和广大党员干部团结带领广大人民群众坚决贯彻落实党中央决策部署，紧紧依靠人民群众坚决打赢疫情防控阻击战
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     习近平强调，各级党委要科学研判形势、精准把握疫情，统一领导、统一指挥、统一行动。（人民日报） #你守护大家我守护你#
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
  </div>
 </body>
</html>