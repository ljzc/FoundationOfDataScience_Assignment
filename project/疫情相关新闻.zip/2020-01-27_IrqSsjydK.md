<html>
 <body>
  <h1 id="title">
   #你守护大家我守护你##你守护大家我守护你#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2020-01-27
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IrqSsjydK">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 58
   </li>
   <li id_no="comment_number">
    评论数量： 128
   </li>
   <li id_no="attitude">
    赞： 1218
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :#你守护大家我守护你#【#女儿把护身符装进护士长爸爸的行李箱#】“ge离病毒但不能ge离爱！永远爱你，英雄爸爸！”今日，中国科大附一院（安徽省立医院）派出10名医务人员驰援湖北
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     出发前，队长樊华9岁的女儿把“护身符”悄悄装进他的行李箱：希望平安归来！
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     把周深摁着亲
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 41
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我偏要讲
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 19
     </li>
    </div>
    <p id="comment_content">
     一切都会好的 都会平安回来的！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     媳妇
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 10
     </li>
    </div>
    <p id="comment_content">
     英雄不止出现在漫威电影中🥼
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-28
    </p>
    <p id="comment_author">
     星际归客
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     好孩子！祝福你健康平安幸福快乐！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     雪中孤影6373590903
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     在抗病毒前线的白衣天使们及各界人士，都是在传播人间最无私的亲情，及团结一致持之以恒的决心来凝聚爱的力量，向您们致敬！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     天洁姑娘
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     加油，武汉；加油，中国。春天快到了，一切都会好起来的[加油]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>