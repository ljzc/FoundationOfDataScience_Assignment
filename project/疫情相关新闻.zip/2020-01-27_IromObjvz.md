<html>
 <body>
  <h1 id="title">
   #武汉市红十字会不存在收取服务费问题##武汉市红十字会不存在收取服务费问题#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2020-01-27
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IromObjvz">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 69
   </li>
   <li id_no="comment_number">
    评论数量： 277
   </li>
   <li id_no="attitude">
    赞： 1763
   </li>
   <li id_no="target">
    疫情相关： True
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【辟谣！#武汉市红十字会不存在收取服务费问题#】近日，有网络传言“武汉市红十字会向上海医疗队收取6%—8%捐赠服务费“
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     记者从中国红十字会了解到，武汉市红十字会只负责接收捐赠物资，具体发放分配，由市卫健委统一根据各医院实际需求调拨安排，运送车辆由各医院自行安排，市红十字会的转运车辆也是通过与武汉市交通委员会协调后，免费运送。武汉市红十字会至今为止的所有工作流程中，均不存在任何收费现象。（新华社）
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     玫瑰星球上的摘星甜心兔子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 169
     </li>
    </div>
    <p id="comment_content">
     希望公布明细
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     终于有猫的希家小黑猫
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 112
     </li>
    </div>
    <p id="comment_content">
     请问在分配物资的时候，有否按照定点捐助的要求？民间捐助为何必须经过红十字会？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-02-01
    </p>
    <p id="comment_author">
     肥猪君34602
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     根本不信！反正抵制你就行了！就是不乐意捐你
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-31
    </p>
    <p id="comment_author">
     阿林的温暖小屋
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     公开透明不只是疫情，所有的款项，捐赠的物资也需要公开
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-28
    </p>
    <p id="comment_author">
     迷雾11细雨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@芨芨花菇朵:你看看你下边的评论，何必跟他争，这就跟云南旅游景点的治安一样……公道自在人心，何必浪费唾沫
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-28
    </p>
    <p id="comment_author">
     春天里的枪
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     老百姓捐款救災，還需要你們恩典？真是恩重如山。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-28
    </p>
    <p id="comment_author">
     春天里的枪
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     連捐款都要官辦，你們對人民有多麼不信任。人民都是壞人，捐款救災的人也是壞人，就你們是好人。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-28
    </p>
    <p id="comment_author">
     曹志彬colin
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@每天都好困困困_:账目公开还需要决策啦？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     第十一签dsyq
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     平时公信力太低了，看着
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     80后不落的太阳
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     公布明细吧，接受物资，库存物资，发放物资，不能空口白话的就让人信啊，有的时候社会监督还是很重要的，谁敢说红会里没有硕鼠
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     剑趁年华
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@贝贝莵:那人民群众只听一面之词呢？互联网这么多反转事件还是不会动脑子？建议相信的人治治自己猪头嗷
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     剑趁年华
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@我的老大他姓杨:不用解释……互联网不是每个人都有脑子
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     剑趁年华
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@禮-樂射御書数:肺炎可以治。你这种猪头治不了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     今天宁又瘦了吗
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@微微纤尘:现在口罩都不好买，公司不发就自己想法吧…开车送什么的，家人重要。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     Mandy-曼-
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     红十字只负责接受物资……其它工作包括运送分配都要听统一安排，真的别随便臆想猜测了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     小怪物派蒙斯特
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     人民网能了解并告知一下哪些医院接收到了捐赠物资吗？医院接收物资一定会有收据或武汉市卫健委调拨详情吧。至今大众都没看到，所以着急
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     梁爽1584
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     公布明细账目就可以辟谣了，慈善的账目没有必要保密，不敢公布就是有问题。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     芨芨花菇朵
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@我的老大他姓杨:我怎么道听途说了，红会不敢正面回应，从来不公布捐款去向，没见过红会帮助过多少贫困户
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     芨芨花菇朵
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@我的老大他姓杨:大家都知道这个事，你还想说什么呀，当年她微博认证是谁给认证的，杨澜采访是假的吗？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我的老大他姓杨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@芨芨花菇朵:整天就只有黑红会，你跟别的网络喷子有什么区别？真相不看只道听途说
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我的老大他姓杨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@芨芨花菇朵:郭美美事件，你看清楚了再说话，看明白了再说话
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我的老大他姓杨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@芨芨花菇朵:郭美美跟红会没有任何关系，都2020年了，脑子扔哪了？整天就盯着郭美美，你跟她有亲还是怎的？还是收了谁的钱天天捧着手机当键盘侠黑红会？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     芨芨花菇朵
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@我的老大他姓杨:郭美美呢，对得起吗？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     _meng_meng
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     完全不相信红十字会…还有医院分到的口罩都被院领导和行政拿完了 一线医生根本没分到
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     明天会真的更好吗
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@明天会真的更好吗:你可以捐一块钱试一下呀，没时间吗？还是差那两块钱的手续费？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     Finish300
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@明天会真的更好吗:嗯
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     明天会真的更好吗
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@Finish300:你现在去捐款不就能看到有木有手续费啦……
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     明天会真的更好吗
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@Finish300:你可以去你们当地给这个单位捐款呀，也会给你这个单子的，单子上也是显示有没有手续费的。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     Finish300
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@明天会真的更好吗:图片评论 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     Finish300
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@明天会真的更好吗:这不是今年的啊
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     Finish300
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@明天会真的更好吗:看到了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     明天会真的更好吗
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@Finish300:你看见了没有？回个信
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     明天会真的更好吗
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@Finish300:图片评论 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     明天会真的更好吗
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@Finish300:好滴，你加我吧
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     坂田靖子94
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@芨芨花菇朵:没有
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我的老大他姓杨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     回复@芨芨花菇朵:不用你相信，红会一直在，不用你知道，红会一直在。我们红会做的事对得起亨利杜南先生的初衷，对得起人道博爱奉献
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     纳兹咩natsume
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     信息账目公开有一点问题吗？人家捐了钱还没有监督权利？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我的老大他姓杨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@李海冰豆:存心对红会有偏见，即使红会做过多少事情，你们也不会看也不希望看，因为郭美美事件从来都不了解真相的你来说，心里只需要认为红十字会是恶的就行，任何一切关于红十字会做过的实事在你眼里都是假的，希望红十字会死了才高兴，就是你这种人，有这种心态，还妄称自己有多善
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我的老大他姓杨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@FlameHazelnico:请你说说红十字会以前作什么孽了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     Finish300
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     红十字会收到3.4亿的捐款，只拿出2000多万来给武汉，这是不是你昨天报道的，请问还有3.1亿哪去了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我的老大他姓杨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@西瓜和大侠:什么时候红会自己把自己的名声搞臭过？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     Finish300
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@明天会真的更好吗:把你照片发给我 我可以发出来
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我的老大他姓杨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@compasslp:你可以不信红十字会，但请别在这丢人
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我的老大他姓杨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@haozi当你老了:来自于你这种人
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我的老大他姓杨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@我是个肉嘟嘟的大团子:红十字会什么时候会做这样的事？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     yoyo的小公主嘉
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@就是瓜田里的一只猹:
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     yoyo的小公主嘉
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     回复@贝贝莵:
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     吉林大自在
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     完善捐赠监督体系。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     终于有猫的希家小黑猫
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@坏掉的小号:我们是在武汉市内内进行协调运输，省外物资可以经由快递等方式。自己的车进不了的，而且我们很多是省内，市内物资的运输帮忙。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     回到最初又会怎样
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     造谣生事的吃太多了吗？有这空去支援疫区
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     东方时节
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@每天都好困困困_:红十字官方一开口辟谣，立马绝多数人信服，那才叫公信力！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     queenbee-yonce
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     或许该想想的是为什么人家会造谣？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     __HMHA
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@每天都好困困困_:你非要扯和教育有关系的话，我只能说，教育我们爱党爱国，不是无脑的爱党爱国，是要勇于指出它的错误，同时能够帮助它进步，我觉得有知识的人是去辨别是非，不是无脑的相信或者不相信
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     坏掉的小号
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@终于有猫的希家小黑猫:不是很明白……现在自己的车可以开进武汉吗？……
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     __HMHA
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@每天都好困困困_:这个事和废青是两码事，不要偷换概念。我很希望红十字会能够真正发挥它的价值，我也知道有很多人会拿这个机构来造谣，但是为什么有人都拿这个机构造谣呢，因为作为一个政府职能部门，它的公信力缺失才是被人攻击的原因。在很多人眼里，这个部门就是发国难财的代表了，为什么呢，他们不透明
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     冯敏微博
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     请务必统计好捐款数额，用好捐款。公开，透明的做出公示。无数企业的爱心，无数捐款人的爱心得到最大的体现。谢谢！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     终于有猫的希家小黑猫
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@世界LP:理论上是的，但是现实是分配优先某些医院而部分“小”医院没有物资。。。更何况，现在根本不存在物资过多的问题
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     每天都好困困困_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@__HMHA:这次疫情让我相信了微博本科率
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     __HMHA
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@幸运花-MG:红十字会成了发国难财的代表了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     旷良勇律师
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     敢不敢把所有的捐赠情况公布出来？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     露月初九星
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@贝贝莵:公信力低就可以造谣了？这是两回事
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     __HMHA
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@每天都好困困困_:我承认有造谣的，但是为什么老百姓总是相信造谣者呢，信息不对称的前提下，官媒自己打脸了多少次，还有公信力吗，红十字会这个事你说是造谣的，我真的很希望是造谣的，但是红十字会敢公开明细吗？他们公信力在民间荡然无存的原因是啥，不应该反思下吗？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     __HMHA
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     红十字会为啥不让评论了呢？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     世界LP
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@终于有猫的希家小黑猫:统一分配可以对每个医院按需分配吧，定向捐助有可能出现有的医院物资充足，有的医院物资缺乏的情况
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我不是天然呆喵
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@就是瓜田里的一只猹:up
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     白色衬衫里思念
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@芨芨花菇朵:没有
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     李海冰豆
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     反正只要是中国红十字做的事情发的消息就不相信
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     钉子or
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@芨芨花菇朵:没有
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     太阳低调
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@终于有猫的希家小黑猫:我捐的校友会，我看清楚并理解了校友会定点支援的三家医院
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     花童雨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     为什么前线医务人员物资紧缺，捐赠物质哪里去了？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     胖垩鱼
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     绝不相信你红十字会
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     葡萄不甜不要钱
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     及时公开物资和资金的收入和发放信息，就是最大的辟谣。谁可以告知物资和资金发放的公示入口？武汉红十字会的官网没找到
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     胖垩鱼
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     相信上海人的说法
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     爱杨浦浦
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@只是贰瑶:对啊，这种时候造谣真的是别有用心。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     想在夏天去看大海
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     那些辟谣的人真是社会巨婴，再说，信息公开也很重要，如果被辟谣的不站出来赶紧澄清，谣言越传越离谱，三人成虎，大家都有责任，但是那些辟谣的人无事生非，可恶之极，必须要重罚。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     爱吃胡萝卜的蓝兔子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这个时候乱传谣言的人还有良心吗
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     明天会真的更好吗
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     我也见过收捐款手续费的。我有照片，但是发不出来，因为我不是VIP
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我是个肉嘟嘟的大团子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     是不太信红十字会，但是这个时候也不至于这么做吧，毕竟风口浪尖上
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     haozi当你老了
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     公信力缺失 怎么来的 心你没点B数吗？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     vosxxh
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     为什么要怕谣  你行不正吗！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     runhew
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     看来也是无风不起浪，红会臭大街了！基本成了过街老鼠！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     随缘去乘风来
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这个辟谣我不信
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     阿隆_along
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     为什么谣言满天飞，我们信息封锁太严，黑箱操作，长期压抑的结果！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     你逗我53880
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 5
     </li>
    </div>
    <p id="comment_content">
     回复@熙熙的蓝莓麦旋风多加奥利奥:感觉中国慈善界就是满是🐭的米缸...
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     ChelseaQ7
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 4
     </li>
    </div>
    <p id="comment_content">
     回复@终于有猫的希家小黑猫:是的，简直是奇葩的要求和流程。我们校友会明明点对点的物流都打通了。从境外获取物资开始到通关到联系跨境物流，结果运到武汉红会来捡现成的了。唉😔无力的很
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     猫宁本喵
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@芨芨花菇朵:没有
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     ChelseaQ7
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 5
     </li>
    </div>
    <p id="comment_content">
     海外捐赠物资必须都要到武汉红十字会，再统一安排。为什么有这样奇葩的要求和流程？民众自发从境外采购的物资直接配送到定点医院不可以么？物流自己可以安排！ 红会的接收分配账单，请透明下！如没有系统，做个H5也是可以接受的，再不济用个Excel表格展示也行！信息透明有这么难么？请继续辟谣说明下。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     时宜xy
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@就是瓜田里的一只猹:@人民网
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     曼陀罗芊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@芨芨花菇朵:没有
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     终于有猫的希家小黑猫
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@ChelseaQ7:估计都存在这个问题，昨天导致校友会也有些沮丧，不明白为什么民间捐助还要多过一道手续，多走一道流程。尤其是我们有一些捐助并非医疗物资，有饮用水，纸尿裤等生活用品。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     你们都会胖胖哒
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@就是瓜田里的一只猹:100%是中间商啊，还是奸商
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     ChelseaQ7
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@终于有猫的希家小黑猫:武大校友会也是一样的情况！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     民声小号
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     公信力的伤什么时候才能治好？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     羊咩咩的腿真白
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@芨芨花菇朵:没有
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     羊咩咩的腿真白
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 4
     </li>
    </div>
    <p id="comment_content">
     回复@贝贝莵:红十字会，人血馒头会！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     戒尺道长
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     还是地方公信力太低
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     羊咩咩的腿真白
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     红十字会我是不会相信的！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     木夜夜
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这个时候就还造谣！湖北都一级战备了！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     每天都好困困困_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@溦蓝天:不要开上帝视角，一开始病毒没搞清不该抓吗？？央视说的你看到了你觉得说错了吗？他们说sars卷土重来说是实验室流出来的，央视说的原因也是不确定是什么病毒，那八个之前只是约谈
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     美层
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     还有流浪街头的病患是真的吗？没有床位就不给确诊？这到底是怎么回事什么情况
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     SaManato·Duffy
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     红十字会算了，08年的时候我一个月生活费就800块钱，拿了400捐灾区，然后就出了个郭美美，呵呵不会再信了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     就是瓜田里的一只猹
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@你们都会胖胖哒:找的厂商据说不是制造商而是中间商
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     非春望夏
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     开个微博事实公开工作详情吧
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     微微纤尘
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     回复@微微纤尘:收费站收费员每天接触来自不同地区的不同人，这些人都不知道和谁接触过从哪儿来，而且现在不能回家不能换班，要一直上到疫情解除，如果你的亲人处于这种情况，你就不会这么说了，请有点同理心同情心
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     你们都会胖胖哒
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@就是瓜田里的一只猹:心里有鬼，怎么敢直面。我怀疑那个基金就是个私人基金，靠捐款赚人血馒头的项目。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     玫瑰星球上的摘星甜心兔子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 6
     </li>
    </div>
    <p id="comment_content">
     回复@就是瓜田里的一只猹:而且很多明星粉丝都是通过这个平台捐款的 请严查
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     皓雪落天涯
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@就是瓜田里的一只猹:上去
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     吸烟就变坏
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     辟谣我信吗
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     qdyjw
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@微微纤尘:现在口罩紧张，我都是用完用84泡一会，晒干继续戴，没办法了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     普洱茶也会开花
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     现在这种情况下还有谣言，造谣的人可能他生来就不配为人的。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     溦蓝天
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@每天都好困困困_:央视报道过的8个造谣者
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     就是瓜田里的一只猹
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@你们都会胖胖哒:官博一直发谁谁谁捐款了多少，面对评论的质疑都选择无视
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     皓雪落天涯
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 15
     </li>
    </div>
    <p id="comment_content">
     回复@贝贝莵:赞同，郭美美事件的影响至今还在，前一阵子9958又给了爱心人士当头一棒，这次我在思源工程上捐的款，现在好像也出问题了，不知道以后应该信任谁
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     就是瓜田里的一只猹
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 6
     </li>
    </div>
    <p id="comment_content">
     回复@就是瓜田里的一只猹:本来集资是打算500万，后来又变更到了1000万。面对捐款人提出的质疑不做出解释。 http://t.cn/A6PVs58v
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     每天都好困困困_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 6
     </li>
    </div>
    <p id="comment_content">
     回复@溦蓝天:最近几个夸张的哪个不是造谣的？？从医生崩溃大哭到魔女小稀，台湾人已经掺和进这场舆论战来了，还有微博小秘书查到了一堆境外ip
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     你们都会胖胖哒
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@就是瓜田里的一只猹:这价格是串通商家发国难财吧
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     嗷呜呜耶
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@就是瓜田里的一只猹:up
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     凯源特别特别特别唯
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 5
     </li>
    </div>
    <p id="comment_content">
     那你倒是把物资发给医院啊！那么多捐助怎么还有那么多医院在网络求助！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     每天都好困困困_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@溦蓝天:目前看到的没有
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     就是瓜田里的一只猹
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     回复@anybetterthing:捐款上写着是给一线用，但购买的并不符合标准。并且大量采购的单价还是14块钱一个。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     钢铁是练不成的
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     除了造谣的恶劣，红十字会和各种基金会层出不穷的贪污腐败也将他们的公信力消磨殆尽。所以群众很轻易的就会相信谣言。毕竟这些会有时候办的事还真不比谣言差了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     白二LeeSsang
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     溦蓝天
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 4
     </li>
    </div>
    <p id="comment_content">
     回复@每天都好困困困_:因为有更不合理的最后被证明是事实
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     赫麦莫拉
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     特殊时期多助力少添乱
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     公子陌言
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     能捐物就捐物吧，或者把想捐的钱买些防护用具送到湖北，捐钱这件事这个时候作用不太大
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     anybetterthing
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@就是瓜田里的一只猹:工业用…买这个给医护人员用是来添乱的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     huwenqing
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这样的造谣太弱智，我根本就不相信红十字会会这样干，在这样的时候，他们又没疯
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     国士贾诩
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@微微纤尘:你还有口罩戴，幸福的了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     彩条三明治要改名沈九娘
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     算了吧，红十字会就这样的名声
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     每天都好困困困_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@miemie咩丶:他们认为zf什么都没干还添乱
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我就是mmjbz啷个办
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@游游的鱼鱼:红会属于高级别的单位 而且规定物资必须从它这里过手 才能发下去
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     陈氏小a
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     现在的红十字  太模糊了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     每天都好困困困_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@禮-樂射御書数:说了没有
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     国士贾诩
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 10
     </li>
    </div>
    <p id="comment_content">
     回复@贝贝莵:失去过信任，长久受质疑…污点不是那么容易洗干净的……
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我就是mmjbz啷个办
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@微微纤尘:老百姓连最基本的口罩都买不到 你们都靠免费发的 可以了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     每天都好困困困_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@人间风物皆有灵性:看看二战时候二鬼子就知道了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     冒耙点
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这次再敢挪用！！必须公布用款明细！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     每天都好困困困_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@冷静_1980:假的朋友圈截图聊天记录是最好造假的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     对山堂卧观云泥
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     干红会鸟事？！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我是雷恩
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 4
     </li>
    </div>
    <p id="comment_content">
     请公布明细账目，毕竟已经没人信任这个机构了，他的公信力在我心里为0，如果不是你出来辟谣，我宁可相信。好了，不多说废话，请派驻官员监督@中国红十字会总会 的任何捐赠，捐赠项目请在微博上每24小时更新一次明细，可以做到吗？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我就是mmjbz啷个办
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@微微纤尘:还是优先医院吧
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     游游的鱼鱼
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     红会有什么能力来调配这么多的财物！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     亮天喽
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     辟谣了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     Melissa沐沐
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这个时候还造谣的人该严厉处罚了！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     冷静_1980
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 9
     </li>
    </div>
    <p id="comment_content">
     回复@人间风物皆有灵性:我个人更倾向于相信上海援鄂医疗队的说法
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     李玥霏12
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     我怎么就信了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     花花儿为什么这样红呀
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 5
     </li>
    </div>
    <p id="comment_content">
     郭美美事件后，红十字会公信力严重下降，所以以后请好好管理，别把政府和很多人的努力因为一个人毁于一旦
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     yoyo就是我800
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     严格追查造谣者，绳之以法。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     每天都好困困困_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     回复@只是贰瑶:恨不得咱们四分五裂
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     每天都好困困困_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 6
     </li>
    </div>
    <p id="comment_content">
     回复@BlackMoon0-0:别急
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     FlameHazelnico
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     你信用破产就这结果。说白了以前自己作孽
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     每天都好困困困_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 21
     </li>
    </div>
    <p id="comment_content">
     回复@贝贝莵:公信力低和满天飞的谣言没有关系吗？？？这种情况这种新闻都有人信脑子呢？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     Stone石子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 8
     </li>
    </div>
    <p id="comment_content">
     透明、公开、公正，自然谣言就少了。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     何如仰山雪
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 6
     </li>
    </div>
    <p id="comment_content">
     那公布一下账目吧
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     故事的de小黄花
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 18
     </li>
    </div>
    <p id="comment_content">
     郭美美事件，对红十字会有点…哎
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     微微纤尘
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 7
     </li>
    </div>
    <p id="comment_content">
     顶我上去！内蒙古高路公司鄂尔多斯关碾房收费站物资供应不足，收费员两天才换一次口罩，手套也是塑料手套，我是收费员家属，现在家人不能回家，恳请援助！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     子书悠悠0025
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     主要是，红十字会不可信！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     北方的晴空
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 17
     </li>
    </div>
    <p id="comment_content">
     红十字会名声已臭
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     水中小小舟
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     日积月累，你信
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     compasslp
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 14
     </li>
    </div>
    <p id="comment_content">
     怎么还有人相信红十字会？还特别是满嘴跑火车的武汉的？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     就是瓜田里的一只猹
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 4
     </li>
    </div>
    <p id="comment_content">
     回复@就是瓜田里的一只猹:官方公布购买的物品并不符合一线医院人员使用标准 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     知足常乐方为本
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     这也日积月累的缺失了些东西，丢了东西
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     犬夜叉脾气真的不太好
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     希望可以公布明细
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     职业铺管人
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     我知道不该质疑，但是还是忍不住…
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     realluoyonghao
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 38
     </li>
    </div>
    <p id="comment_content">
     针对红十字的怀疑 甚至谣言我都是理解的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     遇见在那个雨季
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     造谣的人真是该死，什么心态啊！什么谣都造
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     无畏少女牛魔王
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     能不能公开一下扬州确诊的四例患者信息啊 到现在了 一例信息都不公开 搞得我们人心惶惶的@人民网  求求了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     Deer晗Reed晴
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这个时候怎么还有人传谣
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     终于有猫的希家小黑猫
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 5
     </li>
    </div>
    <p id="comment_content">
     回复@坏掉的小号:我们一律都是自行组织车队送达，医院都有器械科专门对接。统一安排也是需要对接的，不是只要有统一安排就可以省下来这一步。现在的问题是一些定向捐助无法公开透明，是否落实？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     银幕
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     郭美美害了红十字会
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     感觉要成大V了
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     收费也是正常的，毕竟这么大机构需要经费去维持运转，再说了你安排人员转运本身就是要成本的，该收费就得收费，支持
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     翟羽琦
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     真不知道造谣的人都在想什么，真的是太多造谣了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     梦祥曾经的那个男孩
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     每次都有人唯恐天下不乱？！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     暮有悠闲微博
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     事情肯定发生过
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     你要喝娃哈哈嘛
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     红十字会工作人员人手不够，还有很多武汉市民去当志愿者，三班倒24小时不间断。武汉加油！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     为你去放牛
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     造谣真该全家病毒
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     终于有猫的希家小黑猫
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 15
     </li>
    </div>
    <p id="comment_content">
     回复@终于有猫的希家小黑猫:昨日校友会组织物资捐助时，遇到一些来自红十字会的阻碍，希望协助民间捐助，定向捐助，而非将物资全部收在一起由卫健委分发，这样不利于一些校友对亲人朋友所在医院进行的特别捐助和支持。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     请关注辽阳网络卖银
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     中国加油！！武汉加油！！ 帮忙转发评论我的微博。 辽阳网络卖淫，以及辽阳文圣区新城派出所是否涉嫌包庇。我去辽阳举报，人家说我传播淫秽信息，反问我问人家价格干嘛
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     坏掉的小号
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 6
     </li>
    </div>
    <p id="comment_content">
     回复@终于有猫的希家小黑猫:那每个医院还要专门派几个人来对接捐助，自己找车队运送，自己安排搬运……效率不是比统一安排更低了吗
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     GodLes_307
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     多助力，少添乱，谢谢!
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     正贰八经好青年
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     加油武汉！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我为于着迷
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     唯恐天下不乱，查到谁发布出去，拿出去打靶
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     焦糖玛奇芋圆
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     非常时期造谣的都是垃圾
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     相忘不相望iy
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@禮-樂射御書数:都说了没有管理费
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     瑞雪掩晨曦
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     人家正经做公益，后边还有人造谣，不是让人心寒吗
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     lijie19941216
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 23
     </li>
    </div>
    <p id="comment_content">
     反正我捐款我也不会给红十字会，不管多少钱，
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     徐小覃
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     诶呀我去，我真的是...
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     就是瓜田里的一只猹
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 92
     </li>
    </div>
    <p id="comment_content">
     #中华思源工程扶贫基金会捐款使用存疑#  中华思源工程扶贫基金会于2020年1月5日在微博微公益平台发起慈善捐款，截止目前已募集千万善款，在微博上公示的口罩采购价格高且不符合医院需求标准，供货商是中间商且有过罚款记录，公示的采购合同无双方签字盖章不符合规范。请督促@人民网
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     元固心
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     它可千万别贪污
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     亮红色的蔓性夏堇
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     造谣biss
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     芨芨花菇朵
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 43
     </li>
    </div>
    <p id="comment_content">
     红十字会还有公信力吗？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     瘬壻
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 16
     </li>
    </div>
    <p id="comment_content">
     被红十字伤到了 现在捐款直接捐到灾区！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     miemie咩丶
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     回复@miemie咩丶:为什么有人什么都想的那么邪恶，无中生有。巴不得中国什么都腐败，什么都要贪污
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     太阳星晨-奔腾年代
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     捐来的东西参差不齐，能不能用都不好说，人工筛选收点服务费也是正常的吧？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     书画-鉴赏
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     红十字会……哎！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     BlackMoon0-0
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 64
     </li>
    </div>
    <p id="comment_content">
     账目透明有那么难么？！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     何如仰山雪
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 13
     </li>
    </div>
    <p id="comment_content">
     红十字会……算了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     八百标兵-奔北坡
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     希望这次好好分配了，唉，很多还得需要依靠你们的，关乎性命
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     尹芷含霜
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     事情肯定是假的，但是这些人有可能遇到了骗子
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     kerdonny
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     造谣狗不亚于黑心囤货奸商。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     石乐志一百天
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     造谣的通通抓起来！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     微微的生活
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     最佳啊如果是真的伤人心，加油
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     钟爱美男
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 6
     </li>
    </div>
    <p id="comment_content">
     天天辟谣   那些传谣的人怎么想的啊？！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     玫瑰星球上的摘星甜心兔子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 169
     </li>
    </div>
    <p id="comment_content">
     希望公布明细
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     明天的昨天闯天涯
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 6
     </li>
    </div>
    <p id="comment_content">
     红十字会自己让自己烂了，怪谁？群众不相信这个机构还能怪群众？？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     ggdd并肩来日方长
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 25
     </li>
    </div>
    <p id="comment_content">
     非常时期！请这些人管好自己！别给国家添乱！谢谢！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     禮-樂射御書数
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 8
     </li>
    </div>
    <p id="comment_content">
     那管理费呢？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     王三舍人
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     加油
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     安屿he森林
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 12
     </li>
    </div>
    <p id="comment_content">
     之后会公布明细吗？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     miemie咩丶
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 6
     </li>
    </div>
    <p id="comment_content">
     造谣biss
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     一回头青春都哔了狗
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     帮不上忙也别添乱啊，这。。。。。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     dreamboat_1118
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     [加油]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     灬她是莪的夢
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     造谣的都咋想的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     helo狐小小狸
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     造谣的话 请找到源头。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     DEFI周先生
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     加油
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     笨笨其实不是很笨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     那些捐钱的呢
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     无知者bot
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     造谣biss
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     从前拾光
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     抵制造谣
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     wo有一颗小星星
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     这个时候还造谣，应该抓起来！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     终于有猫的希家小黑猫
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 112
     </li>
    </div>
    <p id="comment_content">
     请问在分配物资的时候，有否按照定点捐助的要求？民间捐助为何必须经过红十字会？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     马修羊咩咩
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     想想为什么都容易信谣言
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我睡觉的时候从来不困
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这个一听就是谣言，不信谣不传谣！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     在下兰陵笑笑生
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     北京2003年的经验告诉我们，再复杂的情况，只要社会全面动员起来，疫情都是能够控制的。所以现在需要的不是慌张，而是坚决行动起来，调动起全社会每一个人的责任感，在疫情面前真正做到众志成城。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     人间风物皆有灵性
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 48
     </li>
    </div>
    <p id="comment_content">
     特殊时期多助力少添乱
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     pluto333
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     第一
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     李淳风·
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     造谣必死
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>