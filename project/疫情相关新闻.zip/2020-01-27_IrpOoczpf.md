<html>
 <body>
  <h1 id="title">
   #新冠肺炎最新动态##新冠肺炎最新动态#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2020-01-27
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IrpOoczpf">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 49
   </li>
   <li id_no="comment_number">
    评论数量： 105
   </li>
   <li id_no="attitude">
    赞： 472
   </li>
   <li id_no="target">
    疫情相关： True
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :#新冠肺炎最新动态#【#福建新增21例确诊病例# 累计确诊病例56例】福建卫健委通报，1月26日15时—1月27日8时，我省报告新增新型冠状病毒感染的肺炎确诊病例21例（重症1例），均为输入性病例
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     其中：　　福州市4例（福清市3例、湖北省武汉市1例）；　　泉州市5例（晋江市3例、南安市2例）；　　莆田市8例（秀屿区2例、涵江区2例、城厢区2例、湖北省武汉市1例、湖北省鄂州市1例）；　　南平市1例（光泽县1例）；　　宁德市3例（蕉城区3例）。　　报告新增新型冠状病毒感染的肺炎疑似病例24例。其中：　　福州市10例（福清市2例、连江县2例、仓山区1例、晋安区1例、马尾区1例、长乐区1例、罗源县1例、三明市尤溪县1例）；　　漳州市1例（云霄县1例）；　　泉州市4例（丰泽区1例、鲤城区1例、泉港区1例、南安市1例）；　　三明市2例（沙县2例）；　　莆田市4例（荔城区3例、湄洲湾北岸1例）；　　南平市1例（浦城县1例）；　　龙岩市1例（武平县1例）；　　宁德市1例（古田县1例）。　　截至1月27日8时，福建省累计报告新型冠状病毒感染的肺炎确诊病例56例（危重症1例、重症3例，无死亡病例），均为输入性病例。其中：　　福州市17例（福清市4例、闽清县3例、仓山区2例、永泰县2例、长乐区1例、闽侯县1例、连江县1例、罗源县1例、宁德市古田县1例、湖北省武汉市1例）；　　厦门市4例（泉州市石狮市1例、湖北省武汉市2例、湖南省长沙市1例）；　　漳州市4例（芗城区1例、龙文区1例、诏安县1例、云霄县1例）；　　泉州市10例（晋江市5例、南安市2例、洛江区1例、安溪县1例、石狮市1例）；　　三明市4例（三元区2例、永安市2例）；　　莆田市9例（城厢区2例、涵江区2例、秀屿区2例、湄洲湾北岸1例、湖北省武汉市1例、湖北省鄂州市1例）；　　南平市2例（延平区1例、光泽县1例）；　　宁德市6例（蕉城区3例、霞浦县2例、福安市1例）；　　现有报告新型冠状病毒感染的肺炎疑似病例共46例。其中：　　福州市23例（仓山区6例、长乐区4例、福清市4例、连江县3例、晋安区2例、罗源县1例、马尾区1例、三明市尤溪县1例、湖北省武汉市1例）；　　厦门市3例（湖北省武汉市3例）；　　漳州市1例（云霄县1例）；　　泉州市4例（丰泽区1例、鲤城区1例、泉港区1例、南安市1例）；　　三明市5例（沙县3例、宁化县1例、永安市1例）；　　莆田市5例（荔城区3例、城厢区1例、湄洲湾北岸1例）；　　南平市1例（浦城县1例）；　　龙岩市3例（永定区2例、武平县1例）；　　宁德市1例（古田县1例）。　　新增患者均为武汉返乡、来闽旅游人员。目前，确诊、疑似病例的密切接触者1001人正在接受医学观察。http://t.cn/A6PfKogV
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     宅就是为社会做贡献
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 68
     </li>
    </div>
    <p id="comment_content">
     想每天骂一万遍那些吃野味的垃圾！真的想把他们。妈的挂在东南枝上喜迎八方 然后等到半夜让蝙蝠宝贝倒挂和他嘴对嘴唇齿相依！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     北城夏屿
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 42
     </li>
    </div>
    <p id="comment_content">
     加油福建，一方有难，八方支援，尽绵薄之力助力疫情重灾区，加油！挺住了！我们一直和你在一起！中国加油！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     山高路远马亡
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 31
     </li>
    </div>
    <p id="comment_content">
     乱吃的人真该死，让人家蝙蝠说起来，我特么已尽到最大努力长得不像个食材了，以一己之力封印病毒千年，昼伏夜出，努力扮演一个孤独的潘多拉盒子。万万没想到，还是被人炖了？？？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-02-01
    </p>
    <p id="comment_author">
     艾叶绿的畅想
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     上海、浙江、广东以及福建厦门都已对口罩售卖细则做出调整，并加紧落实，福建福州呢？福建省200多万口罩多少能到福州？在哪里买？怎么购买？不知道。口罩依然“全城售罄”。实际上，药店有货，但大都藏起来供给托关系走后门的人了，有的还一包一包免费送熟人！！八闽首府耶，丢不丢人啊！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-28
    </p>
    <p id="comment_author">
     关注校园暴力事件曝光
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@我快乐了一点点:不清楚，我和你不是一个城市的。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     布谷今天吃饱了吗
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@阿米armyni:好的明白啦
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     阿米armyni
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     此人户籍属于尤溪，但人是在福州发病送医，所以统计在福州的病例中，但括号注明人员籍贯。@生于暮商
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     potatoyul
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@关注校园暴力事件曝光:你知道蕉城区三例除了金涵还有哪里的吗
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     potatoyul
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     谁知道宁德蕉城区除了金涵两例还有一例在哪
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我在二环路的饭店等你
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     如果口罩确实不够用了，甚至只有一个，那么个人使用后的口罩，经过开水高温消毒，再用酒精消毒后能继续使用吗？@中国新闻网 @央视新闻 @头条新闻 @搜狐新闻客户端
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     面包不是超人23
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     福建加油！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     安妮-妮妮
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     晋江具体哪里啊！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     社恐小肥仔
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     爱喝牛奶的兔紫
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     放过我们福建吧，福建是台风的，你不要来抢了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     今年考试过了就改ID
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     后面写湖北省武汉市是什么意思
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     AND-END
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@生于暮商:尤溪人吧
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     辜冬吖
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     吃野味的还吃吗？🙃
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     布谷今天吃饱了吗
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@生于暮商:太奇怪了吧？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     非著名香菜大亨von
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     这个具体程度 希望各省来抄作业
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     这个夏天有幸遇见你
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     别增加了 福清的慌了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     11号入口的鹤儿
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     可怕
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     青衫归去
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@黄黒白:我说三天了屁用没有，就一句：你看楼下一群没戴口罩还聊天的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     雨霖铃_d
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@yolanda-林君:这不是错了，是说明是哪里的人
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     青衫归去
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     我们台江区是不是个不存在的区，宣传没有，不戴口罩聚众聊天，一片祥和的仿佛不是一个世界
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     墓者MZ
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@钮钴禄优秀蟹:全国的物质都不够的...
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     超甜軟糕
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 4
     </li>
    </div>
    <p id="comment_content">
     晋江居然是福建确诊最多的县市我哭了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     choc2
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     请问如何知道具体信息呢？比如 知道在南安哪里，最近去了哪些地方这种
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     初霁Yeah
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     不要再增长了，福建加油啊，一定能挺过去的！相信中国医疗！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     关注校园暴力事件曝光
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@我快乐了一点点:我爸也是
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     清风荷韻一善消百恶
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     🙏🙏🙏
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     potatoyul
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     被我妈气死了，在家呆不住，蕉城区都3例，非逼着我大过年吵架
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     沧冰流漓
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     龙岩给我挺住
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     六粒米米
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     福建挺住，大家没事都宅家里吧，加油[加油][加油][加油]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     人间草木万梦星
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     人社还不推迟体检？？客运都停了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     美丽心情0812
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     2003年的非典，一代人的教训，下一代人就不知道那一年的情况！希望我们国家坚持每一年做宣传学校也作常识课教。重点的是地方官员要及时发现及时上报马上行动做阻断传染方案，不要害怕人民的经济损失！人命才是首位！命没有了钱又何用！新型传染病万一失控非常可怕的一件事！🙏
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     逸詩悠然
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     妈呀越来越多了，啥时候是个头啊
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     情定卡地亚---燕儿
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@yolanda-林君:不是 那个是外地跑过来的 输入性的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     Aisha大
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@王俊凯的女人才不服输:今天吃野味，明天出殡站c位
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     M系小肥君
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     农村根本没宣传，咋整
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     壹滴滴叶
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     福建加油！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     一只有梦想的liu
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     福建挺住福建加油
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     逆时针927
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     泉州10例？？？？？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     青衫归去
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@黄黒白:挺不了了，早上一通电话指责为什么不去刚确诊几个病例的那地方的亲戚家拜年，另一通微信命令转两小时公交车去另个地方拜拜
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     tumbler299
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     福建加油
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     宝宝兰zjl
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     看到了我家在的小县城，心里很方
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     啵唧X一下
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     福建挺住！中国加油！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     _陆家的红烧肉
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     三明预计还会增加，做沙县小吃的太多了。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     牧马人罢了
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     -W115
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     不要再涨了🙏🙏🙏
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     超可爱的树懒
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     @枫落飘火 保护好自己
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     Cola_许
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@宅就是为社会做贡献:这是我听过最动听的中国话
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     W睿智如O
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     大家别乱串门了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     林温温温柔呀
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     啊啊啊啊！马尾区具体在哪里啊！好害怕啊！我家离连江也好近啊！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     CynthiaYV
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     涨的也太快了吧
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     知趣段子手
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     国家有难，咱不添乱！坐在家里，就是贡献！亲戚不走，来年还有！朋友不聚，回头再叙！中国加油，武汉加油
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     yolanda-林君
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     错了.... 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     咸鱼翻不了身___
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     大家加油！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     徐Pp
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     Gan lin niang
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     阿绾再也不想考试了
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     福建加油
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     黑涩的吊带裙
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     怎么这么多
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     傻傻的呆呆的痴痴的笨笨的
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     没有流动就没有新增
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     boxua
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@yolanda-林君:那应该是籍贯
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     快给我来一份
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     小醋碗儿
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     加油
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     权志龙你真好看
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     福建加油！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     Forever-EG
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     哎！加油！待在保护好自己保护好家人
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     一笑勿红尘
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     加油！别再涨了，祈福平安，加油武汉
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     坚果姑娘呢
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     我的家
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     青衫归去
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     玲香希玉
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     福建给我挺住！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     木易即墨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     满杯芋泥不加糖
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     放过泉州吧
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     故里灰灰
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     福建加油
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     咸鱼七不甜
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@钮钴禄优秀蟹:图片评论 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     咸鱼七不甜
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     看看河南省信阳市吧❗️河南省信阳市❗️河南省信阳市❗️河南省信阳市❗️河南省信阳市❗️河南省信阳市❗️❗️❗️❗️❗️❗️❗️❗️物资都告急了❗️物资告急❗️物资告急❗️物资告急❗️物资告急❗️物资告急❗️物资告急❗️物资告急❗️物资告急❗️物资告急❗️物资告急❗️物资告急❗️
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     yolanda-林君
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     莆田市里的写错了，写成湖北武汉了。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     宁小木子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     拜托不要再增加了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     易易华华
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     福建加油！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     后日赶紧哦7
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     福建撑住啊啊啊
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     玺子哥喂过的天鹅
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@妹乙:可以封村吗
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     tokuntokun
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     ……福建马上要深红了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     王俊凯的女人才不服输
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 4
     </li>
    </div>
    <p id="comment_content">
     今天吃野味，明天c位出殡。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     偏裙
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     55不要再增长了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     王俊凯的女人才不服输
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 5
     </li>
    </div>
    <p id="comment_content">
     福建加油。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     一山器
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 20
     </li>
    </div>
    <p id="comment_content">
     湖北省长请听题：湖北省各类口罩的年生产能力到底是多少？（   ）  A：108亿只   B：18亿只   C：108万只   D：18万只      E.   1.08亿只   F:  1.8亿只  秋后算账 现在大局为重。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     我就知道你是狼人
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     我们家附近麻将馆还有人想打麻将
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     小阳要加油努力呀
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     央爸，我怕
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     小飛飛mu-a
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     福建再不要增加了[淚]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     不太冷静的杀手
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     卧槽不要再增加了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     星光捕梦月刊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 8
     </li>
    </div>
    <p id="comment_content">
     农村地方还是很多人打麻将 能不能更严格一点禁止 拜托拜托
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     北城夏屿
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 42
     </li>
    </div>
    <p id="comment_content">
     加油福建，一方有难，八方支援，尽绵薄之力助力疫情重灾区，加油！挺住了！我们一直和你在一起！中国加油！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     OKRs2021
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     总理说：武汉加油
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     宅就是为社会做贡献
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 68
     </li>
    </div>
    <p id="comment_content">
     想每天骂一万遍那些吃野味的垃圾！真的想把他们。妈的挂在东南枝上喜迎八方 然后等到半夜让蝙蝠宝贝倒挂和他嘴对嘴唇齿相依！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     熊熊部落
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 11
     </li>
    </div>
    <p id="comment_content">
     别再增长了，实在太可怕了，中国加油🙏🙏🙏
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     赵天天
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     总理已经在前线考察指导疫情防控工作！2003年的经验告诉我们，再复杂的情况，只要社会全面动员起来，疫情都是能够控制的。所以现在需要的不是慌张，而是坚决行动起来，调动起全社会每一个人的责任感，在疫情面前真正做到众志成城，万众一心，共度难关！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     山高路远马亡
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 31
     </li>
    </div>
    <p id="comment_content">
     乱吃的人真该死，让人家蝙蝠说起来，我特么已尽到最大努力长得不像个食材了，以一己之力封印病毒千年，昼伏夜出，努力扮演一个孤独的潘多拉盒子。万万没想到，还是被人炖了？？？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-27
    </p>
    <p id="comment_author">
     -打工人
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     都给我别在增加了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>