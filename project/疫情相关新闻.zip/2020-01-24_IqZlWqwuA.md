<html>
 <body>
  <h1 id="title">
   #军队部署展开应对突发公共卫生事件联防联控工作##军队部署展开应对突发公共卫生事件联防联控工作#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2020-01-24
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IqZlWqwuA">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 91
   </li>
   <li id_no="comment_number">
    评论数量： 102
   </li>
   <li id_no="attitude">
    赞： 843
   </li>
   <li id_no="target">
    疫情相关： True
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【快讯：#军队部署展开应对突发公共卫生事件联防联控工作#】为认真贯彻落实习主席重要指示精神和中央军委部署要求，军委后勤保障部牵头展开军队应对突发公共卫生事件联防联控工作，组织军队专业医疗力量投入新型冠状病毒感染肺炎疫情的防控
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     前期，军队已组织驻武汉地区部队医院派出40名医护人员，在武汉肺科医院重症监护室展开救治工作。http://t.cn/A6PUalzX
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
  </div>
 </body>
</html>