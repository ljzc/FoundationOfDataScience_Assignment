<html>
 <body>
  <h1 id="title">
   #新冠肺炎最新动态##新冠肺炎最新动态#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2020-01-26
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IrgCSFwIJ">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 34
   </li>
   <li id_no="comment_number">
    评论数量： 90
   </li>
   <li id_no="attitude">
    赞： 474
   </li>
   <li id_no="target">
    疫情相关： True
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :#新冠肺炎最新动态#【#福建新增11例新冠肺炎病例#】1月25日10时—1月26日10时，福建省报告新增输入性新型冠状病毒感染的肺炎确诊病例11例
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     其中：福州市4例（仓山区1例、闽侯县1例、闽清县1例、永泰县1例）；厦门市1例（湖南省长沙市1例）；漳州市1例（云霄县1例）；泉州市1例（晋江市1例）；三明市3例（三元区1例、永安市2例）；宁德市1例（霞浦县1例）。（福建卫健委）http://t.cn/A6Pt10vt
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     命-理-午戌轩
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 77
     </li>
    </div>
    <p id="comment_content">
     ⚠️提醒一下大家，如果一直在家，出现浑身乏力和头晕，不要过分紧张。因为这是长时间躺床上刷手机造成的！ 可以试着翻个身，也可以去客厅散散心。还有体温升高一点点，把空调关了试试，别闷着了。终于到了啥也不干在家躺着就能给社会做贡献的时候了！大家都好好呆着、不要乱跑添乱（既心酸又无奈）
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     荷尓蒙
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 27
     </li>
    </div>
    <p id="comment_content">
     五线沿海城市，真的不知道说啥，前几天转发到群里还别长辈嘲讽了。 我觉得现在很多人有些很奇怪的观念就是: 1.别人没带口罩，我怕丢脸不敢带  2.我又不怕死，人命天定  (您不怕死就搬出去住，您的命由天定，家人们的命由你定?)  3.大惊小怪，非典都闯过来了还怕这?
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     lorenleo
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 14
     </li>
    </div>
    <p id="comment_content">
     湖北省大悟县需要支援!!!大家关注一下!!!国家贫困县!孝感北站所在地!从武汉坐高铁仅需30分钟，g1278列车途经孝感北站，目前有确诊病人，医疗物资严重缺乏!!!
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-29
    </p>
    <p id="comment_author">
     迷失醉鹅_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     @一只羊阿羊
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     Jbebcbdkkskd
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     回复@·窑子·:你继续编？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     琉璃小阿姨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     家里老人不戴口罩，说什么神明保佑啥的，怎么说都不听，吵架吵了好几次了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     _Solstice_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     跪求福建省大中小学延迟开学
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     闲来无事-201807
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     农村宣传不够，很多老人口罩可以一直待下去，扔掉觉得浪费，出门玩就戴上，回来放口袋，出去再戴上，真不知道这戴不戴的区别在哪里，还有的人，在家出门戴着口罩，到外面就把口罩推到下颚，在哪里聊天😂😂，都不知道这是为啥
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     梦回莺歌岭
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@陈山山欠我五块钱:我愿意，你是个啥？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     早起早睡不赖床
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@陈山山欠我五块钱:能不能举报投诉啊 唉
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     愚人静悟
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     我相信政府、相信国家有能力打好这场病毒战争。但我更想知道的是，政府以后怎么处理这个事件带来严重后果，非典之后仍然发生人类自己制造的灾难，不值得深思？以后怎么杜绝类似事件的发生，以及是否建立更严格法律来保护野生动物。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     称尼照相馆
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@lorenleo:
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     称尼照相馆
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     知趣段子手
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     提醒一下大家，如果一直在家，出现浑身乏力和头晕，不要过分紧张。因为这是长时间躺床上刷手机造成的！ 可以试着翻个身，也可以去客厅散散心。还有体温升高一点点，把空调关了试试，别闷着了。终于到了啥也不干在家躺着就能给社会做贡献的时候了！大家都好好呆着、不要乱跑添乱（既心酸又无奈）
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     mmlanthe
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     #党中央向湖北等疫情严重地区派出指导组# 湖北zf：没事，不严重，慢慢的自己会好的。粮食还够 不着急。没什么事。 中央爸爸：你闭嘴给我滚到旁边跪好！老子处理完了再来收拾你！ 我对某些领导班子失望透顶，但是我相信国家队。一顿操作猛如虎，瞬间让我们从绝望中看的希望！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     Liar-will
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     福建加油
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     M小叶子MM
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     我大福建这速度太可怕了，拜托不要在增加了🙏🙏🙏
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     米飯1粥
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     天啊啊啊
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     BonjourBonsoir
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     @Izzydh
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     吧啦嘟啦别飞啦
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     霞浦县不是两个吗？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     MM657
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@命-理-午戌轩:这评论可以堪称2020年最佳吗？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     Be_yourself_Ruby
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     龙岩永定的是哪的啊
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     AbayW诗
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     福安别增！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     _纯洁的老百合_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@-宋子琪:应该是长沙来的，不是福建本地的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     ASAP_CHIU
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@抓住一只艺端:湖北人给plmm点👍🏻
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     妈咪依依19
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     中国加油＾０＾~
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     ccc淳真小肥琴
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     永定区哪边的有两个啊？在龙岩永定的我瑟瑟发抖
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     随心而逝的你
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     浙江都100多例了，疫情地图和武汉一个颜色，同为浙江人，是真的很担心啊！希望不要再多人了，望平安🙏🙏🙏🙏
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     姗儿同学
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     我们这小县城都有1例，太可怕了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     哈密瓜甜瓜西瓜香瓜南瓜子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 19
     </li>
    </div>
    <p id="comment_content">
     真无语，家里长辈个个都嫌弃戴口罩丢脸，然后还要去抢大米？？？迷惑
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     与蚩尤论法道
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     我希望每个地方都这样详细公布出来，真的。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     与蚩尤论法道
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     我希望每个地区都这样详细公布出来，真的。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     石肌娘娘嘻嘻
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     回复@·窑子·:营销号求求你停一停吧
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     往返爱恨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     今年生意难做了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     铅笔小圈
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     福建现在好多地方去抢购米了，气死了，什么脑子，叫不要聚在一起结果凑一块抢大米！！！问我婆婆为啥也去，答曰“只够吃20几天了”，呵呵，合着你前两天刚买的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     打倒哆啦A梦
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     z濮阳夜
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@·窑子·:甘肃偏远农村都开始不让进也不让出，村里村民们都封路了，刚开始中央没发消息时人们都不觉得严重，官方放了消息开启一级响应，大家都重视了，各种活动取消，村头封锁🔒，
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     夏天家的西瓜JUN
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@落春小:哦哦好的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     恶魔在南方
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     不要再增加了！！🙏🙏
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     晴晴同学鸭
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     相信国家 真的我现在不出门了 就希望能好起来 一定可以的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     阿笑的独角兽
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     别再加啦
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     宝贝你太菜了
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     福建人好怕
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     波波莹莹悦悦
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     有点疯的感觉，天天闷在家里，受不了了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     抓住一只艺端
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@卐路飛:福建人都看不下去了这种话
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     抓住一只艺端
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@卐路飛:不要以偏概全!现在是特殊时期 应该众志成城好吗憨批
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     _釋懷·
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 5
     </li>
    </div>
    <p id="comment_content">
     相信政府积极配合，这时候千万不要添乱，希望疫情赶快结束🙏🙏🙏以后都积点口德吧！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     落春小
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@夏天家的西瓜JUN:那个病例来自长沙
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     瑜子酱桃桃
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     我靠啊啊啊啊啊
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     我还很饱n
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 4
     </li>
    </div>
    <p id="comment_content">
     别再增加了 ！！！！！！天公保佑
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     猫跟祢都想了解
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     龙岩别出现
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     _纯洁的老百合_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 4
     </li>
    </div>
    <p id="comment_content">
     图片评论 http://t.cn/A6Pt1DQR
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     夏天家的西瓜JUN
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     厦门市后面写的湖南长沙是什么？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     詹理斯的爱
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     全国人民一起努力、不外出，不聚会，老老实实在家待着、
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     命-理-午戌轩
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 77
     </li>
    </div>
    <p id="comment_content">
     ⚠️提醒一下大家，如果一直在家，出现浑身乏力和头晕，不要过分紧张。因为这是长时间躺床上刷手机造成的！ 可以试着翻个身，也可以去客厅散散心。还有体温升高一点点，把空调关了试试，别闷着了。终于到了啥也不干在家躺着就能给社会做贡献的时候了！大家都好好呆着、不要乱跑添乱（既心酸又无奈）
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     抓住一只艺端
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@卐路飛:?怎么可以这样
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     打倒哆啦A梦
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     不是吧
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     再不开心也要吃饭
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     求求重视泉州吧，安溪县下的乡村都不重视，没有喇叭喊话，虽然有警察在路上巡逻，但是村里还是该干嘛干嘛，没有说明这个严重性，年轻人说得再多也没有政府说管用，求求重视一下吧
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     曉桃紫
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     太吓人了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     北城夏屿
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     别再增加了🙏
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     肆月蜜桃
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     啊！求求不要再增加了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     陈琳榕_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     梦回莺歌岭
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     如果您来自疫区，您曾到过武汉，或接触过从武汉回来者，请不要去接触别人，请自觉居家观察14天！ 请家人不参与社会活动，不待客！这是觉悟也是责任，关乎您和您家人及全社会的健康！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     goffv
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     加油吖武汉加油湖北加油中国！我们一定能
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     山崎奈枝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     ！我的天别再增加了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     羊羊祥崽
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     福建官方微博都没？？这是啥情况
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     叫不醒我就算了
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     希望不要再增加啦
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     果然夏天就是要吃沙冰
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     看到我家小县城了……唉
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     早起早睡不赖床
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     回复@闫忠文bot:这是住在微博吗？每条新闻下面都看到你
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     泥鳅面相
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     形势越来越严峻
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     aabbccizu
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 7
     </li>
    </div>
    <p id="comment_content">
     湖南省长沙市?
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     荷尓蒙
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@·窑子·:！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     遥寄此夜清辉未采
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 7
     </li>
    </div>
    <p id="comment_content">
     图片评论 http://t.cn/A6Pt1HL1
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     荷尓蒙
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 27
     </li>
    </div>
    <p id="comment_content">
     五线沿海城市，真的不知道说啥，前几天转发到群里还别长辈嘲讽了。 我觉得现在很多人有些很奇怪的观念就是: 1.别人没带口罩，我怕丢脸不敢带  2.我又不怕死，人命天定  (您不怕死就搬出去住，您的命由天定，家人们的命由你定?)  3.大惊小怪，非典都闯过来了还怕这?
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     澈月Millooo
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     初初见你Vin
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     韩国的KF94可以吗？听说和N95效果一样
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     杉菜姐姐
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     好难受啊！别再增加了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     不要搞鬼w
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     求求疫情不要扩散了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-26
    </p>
    <p id="comment_author">
     lorenleo
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 14
     </li>
    </div>
    <p id="comment_content">
     湖北省大悟县需要支援!!!大家关注一下!!!国家贫困县!孝感北站所在地!从武汉坐高铁仅需30分钟，g1278列车途经孝感北站，目前有确诊病人，医疗物资严重缺乏!!!
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>