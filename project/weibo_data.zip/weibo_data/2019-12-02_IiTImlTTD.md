<html>
 <body>
  <h1 id="title">
   #一撇一捺看发展##一撇一捺看发展#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-02
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IiTImlTTD">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 58
   </li>
   <li id_no="comment_number">
    评论数量： 83
   </li>
   <li id_no="attitude">
    赞： 259
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :#一撇一捺看发展#【世界最薄！0.004毫米的铝箔你见过吗？】你知道吗？在这里，生产有#世界上最薄的铝箔#“0.0045毫米，大约相当于头发丝直径的1/20
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     ”云南昆明近年来不光走出了一条绿色生态发展之路，也在工业制造、生活服务、尖端科技、交通物流等方面因地制宜、转型升级。科技创新“混动”绿色生态 春城昆明装上“青春引擎”
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     憨逼给本仙爬
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 14
     </li>
    </div>
    <p id="comment_content">
     厉害了我的国！！！！吹爆
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     雾似书中人
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 6
     </li>
    </div>
    <p id="comment_content">
     大赞
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-06
    </p>
    <p id="comment_author">
     辣椒呀呀呀
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     骄傲，我家那里
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     OAHZUH
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     几年前还在湖南晟通工作，也是有这类产品的加工产线，那个时候的出品厚度还是0.006，其实是属于无菌包装里比较好的了，现在双零箔能做到这样真的很自豪，每个0.001真的都是千万倍的努力。希望以后我们不仅仅能造出这样的双零箔，而且是要用自己的国产设备造出这样的双零箔！祖国加油！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     雨后阿
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     雾霾好重
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>