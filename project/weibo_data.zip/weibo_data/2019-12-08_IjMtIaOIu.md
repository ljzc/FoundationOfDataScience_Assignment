<html>
 <body>
  <h1 id="title">
   “人权”幌子掩盖不了险恶用心“人权”幌子掩盖不了险恶用心
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-08
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjMtIaOIu">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 97
   </li>
   <li id_no="comment_number">
    评论数量： 126
   </li>
   <li id_no="attitude">
    赞： 761
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【人民日报评美通过涉疆法案：“人权”幌子掩盖不了险恶用心】美方打着保护“人权”的幌子对中国指手画脚，目的无非是想借所谓新疆问题丑化中国的形象，破坏中国的稳定，遏制中国的发展，这充分暴露了美方妄图“以疆制华”的险恶用心
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     奉劝美国收回黑手，停止自取其辱的闹剧！“人权”幌子掩盖不了险恶用心
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-08
    </p>
    <p id="comment_author">
     王子的小玫瑰哦
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 76
     </li>
    </div>
    <p id="comment_content">
     我们宿舍，还有联谊宿舍刚刚全体举手表决，支持加州人民独立诉求方案
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-08
    </p>
    <p id="comment_author">
     柠檬·星
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 21
     </li>
    </div>
    <p id="comment_content">
     中国内政，不容他人干涉，美国可以回家洗洗睡吧
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-08
    </p>
    <p id="comment_author">
     一点清风----
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     转发微博
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-09
    </p>
    <p id="comment_author">
     痞子老师
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     “奉劝”？我勒个去
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-09
    </p>
    <p id="comment_author">
     lz不想考试
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-09
    </p>
    <p id="comment_author">
     氼菩萨过奖
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>