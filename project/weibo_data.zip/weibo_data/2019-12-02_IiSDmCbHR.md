<html>
 <body>
  <h1 id="title">
   #网贷被骗后组团诈骗##网贷被骗后组团诈骗#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-02
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IiSDmCbHR">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 57
   </li>
   <li id_no="comment_number">
    评论数量： 68
   </li>
   <li id_no="attitude">
    赞： 224
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :#网贷被骗后组团诈骗#【网贷被骗后竟“主动学习” 拉起诈骗团队害人】近日，常州警方赴山西破获“闪宝”网络诈骗团伙，抓获8人，现场查获大量诈骗“剧本”
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     主犯陈某交代，他曾因网贷被骗，后成为骗子的下线，学到骗术后，自己拉拢7人组成团队。目前8人已被刑拘。@江苏新闻 荔直播的秒拍视频
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     尼奇窝窝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 17
     </li>
    </div>
    <p id="comment_content">
     现学现卖啊！脑子用在正当地方不行么？这下可以放个长假好好休息了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     吾家有儿初长成眉眼如画温如言
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 7
     </li>
    </div>
    <p id="comment_content">
     这是从哪里跌倒从哪里起来？这智商用来坑蒙拐骗可惜了……
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-03-31
    </p>
    <p id="comment_author">
     啥呀博主
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这就是国家不管的后果
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-08
    </p>
    <p id="comment_author">
     防骗百科
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     网贷是如何养成的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-03
    </p>
    <p id="comment_author">
     王艳芝芝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     我被在网上骗了，叫李明秀，在石家庄，希望大家都找到还我救命钱
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>