<html>
 <body>
  <h1 id="title">
   #铁路安全宣传版抖肩舞##铁路安全宣传版抖肩舞#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-07
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjHHouGTG">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 210
   </li>
   <li id_no="comment_number">
    评论数量： 214
   </li>
   <li id_no="attitude">
    赞： 948
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【#铁路安全宣传版抖肩舞#来啦，让文明乘车更美丽】“第一位女子叫叶叶，有一天进站上车，她把超大瓶摩丝藏在袖子里；第二位女子叫巧巧，她在车站边打电话边跳舞，还踩进了安全黄线
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     ”当叶叶和巧巧遇到铁路安全宣传版抖肩舞，会明白什么道理呢↓↓
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-07
    </p>
    <p id="comment_author">
     枯萎的星系
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 85
     </li>
    </div>
    <p id="comment_content">
     一边尬一边看
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-07
    </p>
    <p id="comment_author">
     小嘎嘎_0716
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 53
     </li>
    </div>
    <p id="comment_content">
     这个真的太洗脑了！笑死了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-07
    </p>
    <p id="comment_author">
     小嘎嘎_0716
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 28
     </li>
    </div>
    <p id="comment_content">
     最后坐着轮椅的也在跳抖肩舞，真的太魔性了！为这些贴心又有趣的铁路工作人员点赞！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-17
    </p>
    <p id="comment_author">
     南瓜冬心
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     @王王王王中王-  果然一尬一边看
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-17
    </p>
    <p id="comment_author">
     我们去烫爆炸头吧
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     @吃胡萝卜丸子啊 笑死我了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>