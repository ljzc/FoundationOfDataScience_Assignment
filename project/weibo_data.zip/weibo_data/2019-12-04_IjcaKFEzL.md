<html>
 <body>
  <h1 id="title">
   #民民小调查##民民小调查#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-04
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjcaKFEzL">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 132
   </li>
   <li id_no="comment_number">
    评论数量： 366
   </li>
   <li id_no="attitude">
    赞： 12185
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :#民民小调查#【你最讨厌弹窗广告哪一点？】打开电脑网页、手机客户端，一些“弹窗”往往扑面而来，有信息推广，有商业广告…业内人士透露，多数弹窗都是推广公司与浏览器平台合作，按点击量收费并分成
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     #你被弹窗广告困扰过吗#？你最讨厌弹窗广告哪一点？ 你最讨厌弹窗广告哪一点？
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     做梦在泡澡
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 203
     </li>
    </div>
    <p id="comment_content">
     全部都讨厌
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     医美小卖部-
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 98
     </li>
    </div>
    <p id="comment_content">
     那个关闭的按钮太小的，很多时候点了那里，弹出来更多的网址
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     谨慎吃瓜的yy
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 75
     </li>
    </div>
    <p id="comment_content">
     点叉号一直关不掉，还会不停弹出新的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-06-30
    </p>
    <p id="comment_author">
     啥锅Laura
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     都是没营养的广告，一点啊不喜欢
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>