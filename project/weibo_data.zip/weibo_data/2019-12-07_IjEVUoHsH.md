<html>
 <body>
  <h1 id="title">
   #陕西榆林定边县委原书记被撤职##陕西榆林定边县委原书记被撤职#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-07
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjEVUoHsH">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 50
   </li>
   <li id_no="comment_number">
    评论数量： 70
   </li>
   <li id_no="attitude">
    赞： 284
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【因在脱贫攻坚工作中履职不力 #陕西榆林定边县委原书记被撤职#】据陕西省纪委监委通报：榆林市定边县委原书记崔博因在脱贫攻坚工作中履职不力问题受到撤销党内职务、政务撤职处分
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     据了解，崔博任定边县委书记期间，在脱贫攻坚工作中，不认真履行第一责任人职责，贯彻落实中央脱贫攻坚政策不坚决、打折扣，定边县在脱贫摘帽后工作有所松懈，存在责任落实、政策落实和工作落实不到位问题。今年年4月，国务院扶贫办向陕西反馈2018年脱贫攻坚成效考核发现的问题中，有6条涉及定边县。崔博还存在其他违纪问题。8月，崔博受到撤销党内职务、政务撤职处分，降为四级调研员。
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
  </div>
 </body>
</html>