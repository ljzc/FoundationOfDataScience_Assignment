<html>
 <body>
  <h1 id="title">
   #华为宣布起诉美国联邦通信委员会##华为宣布起诉美国联邦通信委员会#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-05
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjkXChSoe">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 75
   </li>
   <li id_no="comment_number">
    评论数量： 258
   </li>
   <li id_no="attitude">
    赞： 972
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【#华为宣布起诉美国联邦通信委员会#】华为今天在美国法院提交起诉书，请求法院认定美国联邦通信委员会（FCC）有关禁止华为参与联邦补贴资金项目的决定违反了美国宪法和《行政诉讼法》
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     （央视）
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
  </div>
 </body>
</html>