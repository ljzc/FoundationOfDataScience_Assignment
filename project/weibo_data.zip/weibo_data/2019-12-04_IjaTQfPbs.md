<html>
 <body>
  <h1 id="title">
   #广西查扣近10吨象牙##广西查扣近10吨象牙#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-04
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjaTQfPbs">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 240
   </li>
   <li id_no="comment_number">
    评论数量： 212
   </li>
   <li id_no="attitude">
    赞： 948
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【#广西查扣近10吨象牙#！它们活着该多好】2日，据南宁海关介绍，今年以来，该关严厉打击象牙等濒危物种走私和非法贸易，摧毁一批濒危物种走私团伙，立案查办该类案件案值逾20亿元人民币，查扣涉案象牙超9673千克
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     没有买卖就没有伤害，保护野生动物！支持的转！（中新网）
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     老表映山红
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 74
     </li>
    </div>
    <p id="comment_content">
     贪心不足。死有余辜。斩了吧！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     胖胖的夜宵君
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 51
     </li>
    </div>
    <p id="comment_content">
     没有买卖就没有杀害！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     班喵不知道
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 28
     </li>
    </div>
    <p id="comment_content">
     没有买卖，就没有伤害
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-07
    </p>
    <p id="comment_author">
     兮时对对对
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     走私犯给爷死
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-07
    </p>
    <p id="comment_author">
     _执着先生_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@2姐爱蹦哒:再看一次
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     狄家台社区网络文明传播志愿者
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     把他们的牙也拔了试试
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>