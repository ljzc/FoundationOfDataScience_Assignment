<html>
 <body>
  <h1 id="title">
   #百名火箭军女新兵宣誓入列##百名火箭军女新兵宣誓入列#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-07
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjDogsinB">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 113
   </li>
   <li id_no="comment_number">
    评论数量： 115
   </li>
   <li id_no="attitude">
    赞： 957
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【英姿飒爽！#百名火箭军女新兵宣誓入列#】“我是中国人民解放军军人，我宣誓！”铿锵誓言，豪迈宣誓，近日火箭军某部举行2019年度新兵授衔暨宣誓仪式，近百名女新兵被授予火箭军列兵军衔，成为名副其实的火箭军战士
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     ！
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-07
    </p>
    <p id="comment_author">
     尼奇窝窝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 20
     </li>
    </div>
    <p id="comment_content">
     当代花木兰，最帅最美女兵
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-07
    </p>
    <p id="comment_author">
     粥粥_WHITE
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 10
     </li>
    </div>
    <p id="comment_content">
     好棒呀小姐姐们，英姿飒爽！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-22
    </p>
    <p id="comment_author">
     宸爱坤
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     第22秒和第34秒是我姐姐,我很骄傲。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>