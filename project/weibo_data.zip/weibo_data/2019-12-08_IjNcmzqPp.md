<html>
 <body>
  <h1 id="title">
   #父亲割肝又抽髓给了孩子3次生命##父亲割肝又抽髓给了孩子3次生命#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-08
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjNcmzqPp">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 1946
   </li>
   <li id_no="comment_number">
    评论数量： 4333
   </li>
   <li id_no="attitude">
    赞： 48493
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【#父亲割肝又抽髓给了孩子3次生命#】“妈妈我们回家吧，今年我们回家过年好吗？花钱太多，你再生一个宝宝，就不用天天哭了
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     ”2019年初临近春节，5岁的王启铭肝脏衰竭，其父王欢割肝救子。出院不到1个月，小启铭患上了急性移植物抗宿主病。捐肝不到4个月的王欢又为爱子捐出骨髓…青流视频的秒拍视频
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
  </div>
 </body>
</html>