<html>
 <body>
  <h1 id="title">
   #东北虎豹国家公园首次拍摄到獐##东北虎豹国家公园首次拍摄到獐#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-07
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjFVqiAZy">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 357
   </li>
   <li id_no="comment_number">
    评论数量： 521
   </li>
   <li id_no="attitude">
    赞： 6625
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【新发现！#东北虎豹国家公园首次拍摄到獐#】12月5日，东北虎豹国家公园天桥岭分局辖区内拍摄到一段鹿科动物视频
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     经专家鉴定，确认为我国国家二级重点保护动物——獐。这是东北虎豹国家公园区域首次记录到这种珍稀物种，同时也是迄今为止该物种的最北记录点。獐，又名河麂、牙獐，隶属于哺乳纲偶蹄目鹿科獐属，是中国国国家二级重点保护动物，被列入世界自然保护联盟(IUCN)濒危物种红色名录易危(VU)级别。@央视财经 央视财经的微博视频
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-07
    </p>
    <p id="comment_author">
     小嘎嘎_0716
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 690
     </li>
    </div>
    <p id="comment_content">
     是傻狍子吗！？！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-07
    </p>
    <p id="comment_author">
     活着到底是为谁而活
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 303
     </li>
    </div>
    <p id="comment_content">
     獐:我就来看看，溜了溜了，哎哟，雪好滑，赶快回家
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-03-07
    </p>
    <p id="comment_author">
     老虎爱美丽333
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     啥叫  中国国国家
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-03-07
    </p>
    <p id="comment_author">
     Oo鹤心瞳oO
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@公子无妆Pony:獐头鼠目吧
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>