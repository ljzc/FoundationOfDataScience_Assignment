<html>
 <body>
  <h1 id="title">
   #情侣在公共场合亲热你怎么看##情侣在公共场合亲热你怎么看#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-08
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjOtgtSjg">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 130
   </li>
   <li id_no="comment_number">
    评论数量： 308
   </li>
   <li id_no="attitude">
    赞： 23561
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【#情侣在公共场合亲热你怎么看#？】近日，在南京一餐厅，一对情侣吃饭时一直亲热，邻桌一位宝爸上前提醒时，却遭反怼，“你跟你老婆不亲热，哪儿有小孩呢？”双方因此打了起来
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     情侣该不该在公共场合亲热？#民民小调查# 情侣该不该在公共场合亲热？
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-08
    </p>
    <p id="comment_author">
     发刊物--联系我
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 463
     </li>
    </div>
    <p id="comment_content">
     我不羡慕那些公共场合接吻的，只羡慕年老的大街上互相搀扶的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-08
    </p>
    <p id="comment_author">
     Lucie_多多
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 161
     </li>
    </div>
    <p id="comment_content">
     公共场合亲热跟动物有什么区别
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-12
    </p>
    <p id="comment_author">
     宝贝笑看世界
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     我参与了@人民网 发起的投票【情侣该不该在公共场合亲热？】，我投给了“注意度，牵手、拥抱可以”这个选项，你也快来表态吧~
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-11
    </p>
    <p id="comment_author">
     brain020
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@Lucie_多多:典型的是发情期到了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>