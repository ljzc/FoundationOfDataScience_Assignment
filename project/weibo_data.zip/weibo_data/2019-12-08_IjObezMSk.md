<html>
 <body>
  <h1 id="title">
   #情侣在孩子面前亲热引殴斗##情侣在孩子面前亲热引殴斗#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-08
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjObezMSk">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 94
   </li>
   <li id_no="comment_number">
    评论数量： 846
   </li>
   <li id_no="attitude">
    赞： 5314
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【#情侣在孩子面前亲热引殴斗#】近日，南京，许先生一家在饭店吃饭，对面的刘先生和女友一直在亲热，女儿问“叔叔阿姨在做什么”，许先生去提醒，对方让他们给女儿换个位置，还称，“你跟你老婆不亲热，哪儿有小孩呢？”因为这句话，双方打了起来
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     刘先生认为话没错。#情侣在公共场合亲热你怎么看#？@荔枝新闻 JSTV荔枝视频的秒拍视频
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-08
    </p>
    <p id="comment_author">
     发刊物--联系我
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 813
     </li>
    </div>
    <p id="comment_content">
     应该回怼他：是不是你爹妈在餐厅当众亲热然后有了你
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-08
    </p>
    <p id="comment_author">
     标致的小馄饨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 708
     </li>
    </div>
    <p id="comment_content">
     别人当着你女儿面亲热不行，你当着自己女儿面打架可以。家教满分
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-08
    </p>
    <p id="comment_author">
     尼奇窝窝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 445
     </li>
    </div>
    <p id="comment_content">
     我不羡慕那些公共场合接吻的，只羡慕年老的大街上互相搀扶的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-02-15
    </p>
    <p id="comment_author">
     虞大才
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-02-15
    </p>
    <p id="comment_author">
     虞大才
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@柠檬西瓜_:牵手接吻还好，一直在那啃有点难看还摸的真的是
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-21
    </p>
    <p id="comment_author">
     aga14513
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@趁早把生活折腾得不成样子:你保护不过来啊，这是遇到还算好的啊，遇到无赖的，你咋教育啊，你也教育不过来啊
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>