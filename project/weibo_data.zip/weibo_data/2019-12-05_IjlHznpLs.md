<html>
 <body>
  <h1 id="title">
   #制假网红减肥药还拿老爸试药##制假网红减肥药还拿老爸试药#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-05
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjlHznpLs">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 64
   </li>
   <li id_no="comment_number">
    评论数量： 138
   </li>
   <li id_no="attitude">
    赞： 503
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【成本200卖3万！男子#制假网红减肥药还拿老爸试药#】禁药拌入玉米粉冒充减肥药，成本一毛，日产上万粒，网上推广销售…警方破获一起网上生产、销售有毒、有害食品案
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     主犯纪某称，为试验效果和人体对禁药含量多少的接受程度，叫自己的父亲试吃，结果父亲腹泻住院…（都市快报）成本200能卖3万！90后制假抖音网红减肥药，甚至拿老爸试药！服药者往往腹泻不止
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     小嘎嘎_0716
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 83
     </li>
    </div>
    <p id="comment_content">
     拿老爸试药是重点！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-23
    </p>
    <p id="comment_author">
     V8贝勒爷
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这个人怕不是个精神病患者吗？让他父亲试药。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-06
    </p>
    <p id="comment_author">
     解老板puls
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@爵爷200709:重点不在这里好吗
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-06
    </p>
    <p id="comment_author">
     ____夏__
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这是真的坑爹货
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>