<html>
 <body>
  <h1 id="title">
   #每年从沙里挖出130多部手机##每年从沙里挖出130多部手机#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-11-29
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IirwWfNoN">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 58
   </li>
   <li id_no="comment_number">
    评论数量： 79
   </li>
   <li id_no="attitude">
    赞： 474
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【敦煌鸣沙山 民警#每年从沙里挖出130多部手机#】因为每年都会从景区的沙子中挖出百余部手机，甘肃敦煌市公安局鸣沙山月牙泉景区名胜区治安派出所受到关注
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     “挖”出来的手机都是游客不小心掉落的，因景区大部分都是沙漠，手机很容易被迅速掩埋，找起来难度很大。@中国长安网 中国长安网的微博视频
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     木木匕禾页的小世界
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 15
     </li>
    </div>
    <p id="comment_content">
     长得好好看
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     吾家有儿初长成眉眼如画温如言
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 7
     </li>
    </div>
    <p id="comment_content">
     手机表示它也不想把埋骨沙漠下，呼叫主人无音讯，💔
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     器宇--轩昂
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     请问还缺人嘛?手不手机的无所谓，主要想去月牙泉挖沙，
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     yuan子能
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     @人民网 不是有个仪器叫“金属探测仪”吗？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>