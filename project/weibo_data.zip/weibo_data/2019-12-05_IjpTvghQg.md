<html>
 <body>
  <h1 id="title">
   #油漆工自学钢琴可弹百首曲子##油漆工自学钢琴可弹百首曲子#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-05
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjpTvghQg">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 176
   </li>
   <li id_no="comment_number">
    评论数量： 96
   </li>
   <li id_no="attitude">
    赞： 1045
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     【现实版海上钢琴师！#油漆工自学钢琴可弹百首曲子#】辽宁营口，在钢琴厂做油漆工的董师傅，利用中午休息时间自学钢琴，熟悉每一个琴键的音调
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     他虽然看不懂琴谱，但听过的歌都能用钢琴弹出来，目前他会弹一两百首曲子。网友：音乐无界限，有梦想谁都了不起
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-06
    </p>
    <p id="comment_author">
     笨笨哈气
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     厉害了，天赋啊，人才有很多，只是有的人平台不一样，珍惜你所拥有的，如果换成别人你可能什么也不是
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-06
    </p>
    <p id="comment_author">
     水晶公主0809
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     人一定要梦想，生活虽苦，但只要你还有梦想并能为之坚持努力，你就一定能尝到实现梦想的甜。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-06
    </p>
    <p id="comment_author">
     香香1941
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     有天赋呀
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>