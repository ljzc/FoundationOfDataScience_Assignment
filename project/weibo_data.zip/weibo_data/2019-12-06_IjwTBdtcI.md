<html>
 <body>
  <h1 id="title">
   #烧烤店提供免费餐A套##烧烤店提供免费餐A套#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-06
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjwTBdtcI">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 127
   </li>
   <li id_no="comment_number">
    评论数量： 150
   </li>
   <li id_no="attitude">
    赞： 1625
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【#烧烤店提供免费餐A套# 青年男女吃完留下500元】22年前，张小军最窘迫时，一位面馆老板免费给了他一碗面
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     如今他开了家烧烤店，为困难者推出免费“A套餐”。最近，一对青年男女吃完套餐后悄悄留下500元。张小军说，食客应该也是想做好事，对自己也是鼓励。
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-06
    </p>
    <p id="comment_author">
     重庆共青团
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 110
     </li>
    </div>
    <p id="comment_content">
     传递温暖，为爱心点赞
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-06
    </p>
    <p id="comment_author">
     玲玲振玉
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 63
     </li>
    </div>
    <p id="comment_content">
     都是好人，真的很棒
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-06
    </p>
    <p id="comment_author">
     尼奇窝窝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 52
     </li>
    </div>
    <p id="comment_content">
     当好人遇到好人。。。。。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-18
    </p>
    <p id="comment_author">
     Sky心境
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     人间自有真情在
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-15
    </p>
    <p id="comment_author">
     恩恩宝宝6969
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     西安人的歌
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-07
    </p>
    <p id="comment_author">
     北京崔宏伟
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     知恩图报，传递温暖
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>