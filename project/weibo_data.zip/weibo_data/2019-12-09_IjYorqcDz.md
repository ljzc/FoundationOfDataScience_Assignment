<html>
 <body>
  <h1 id="title">
   #刚抱孩子离开一秒厨房爆燃##刚抱孩子离开一秒厨房爆燃#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-09
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjYorqcDz">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 72
   </li>
   <li id_no="comment_number">
    评论数量： 140
   </li>
   <li id_no="attitude">
    赞： 840
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【惊险！#刚抱孩子离开一秒厨房爆燃#】6日，福建福州，一居民家中厨房突然爆燃发出巨大火光，冲击波将屋内不少东西震碎，连不锈钢的大门也未幸免
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     监控画面中，爆燃前一秒，女主人刚把要走进厨房的小孩带离，幸运躲过一劫。事故未造成人员伤亡，目前原因正在调查。
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-09
    </p>
    <p id="comment_author">
     懒得想名字滴某寞
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 171
     </li>
    </div>
    <p id="comment_content">
     如果小孩没有走进去，那妈妈就被炸到了，如果妈妈不把孩子带出去，那就都炸到了，真是幸运呀。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-09
    </p>
    <p id="comment_author">
     小嘎嘎_0716
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 76
     </li>
    </div>
    <p id="comment_content">
     真的好幸运！厨房用火真的要特别注意安全！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-09
    </p>
    <p id="comment_author">
     今天可以去你家蹭饭吗
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 61
     </li>
    </div>
    <p id="comment_content">
     大难不死 必有后福，都是有福气的人！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-12
    </p>
    <p id="comment_author">
     GUO强家生活是否安定
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     安全意识比较差，还好有惊无险
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-11
    </p>
    <p id="comment_author">
     TR丶风起时分
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@梨夏姑娘:为什么会都想着安装监控呢？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-10
    </p>
    <p id="comment_author">
     罗梓意44182
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     应该是密闭空间可燃气体泄漏囤积遇火爆炸，工业上用气区域的密闭柜需要开气孔防止囤积可燃气体，造成隐患，家居这种情况较少，目前还没有这种防范措施。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>