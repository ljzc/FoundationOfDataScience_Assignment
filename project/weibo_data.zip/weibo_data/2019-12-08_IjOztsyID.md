<html>
 <body>
  <h1 id="title">
   #幼儿被遗弃垃圾站##幼儿被遗弃垃圾站#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-08
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjOztsyID">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 62
   </li>
   <li id_no="comment_number">
    评论数量： 168
   </li>
   <li id_no="attitude">
    赞： 880
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【#幼儿被遗弃垃圾站# 留字条称孩子不能吃鸡蛋、喝牛奶】12月5日，四川绵阳
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     好心人在一垃圾站旁听见孩子啼哭，苦等半小时无人认领后报警。民警在幼儿身边的包内，发现一张纸条，写着出生日期以及“不能吃鸡蛋喝牛奶”。目前，孩子已送往福利院，警方已立案。
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-08
    </p>
    <p id="comment_author">
     阿尔卑和圣西罗
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 127
     </li>
    </div>
    <p id="comment_content">
     这种就不要寻亲了，找到了送回去是为了再次遗弃吗？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-08
    </p>
    <p id="comment_author">
     烊烊AD钙奶
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 58
     </li>
    </div>
    <p id="comment_content">
     心疼小宝宝，你不能养干嘛生他
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-25
    </p>
    <p id="comment_author">
     在雨中跳巴赫
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@在雨中跳巴赫:无论是肉体的不健全还是智商发育不全，要想抚养成人，亲人得付出一辈子的看不到回报的心血，死了都在担心没人照顾他。可以说是命吧。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-18
    </p>
    <p id="comment_author">
     遇见li念
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     看到这种丢小孩的父母就来火，心怎么就这么狠，心痛小宝贝
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-11
    </p>
    <p id="comment_author">
     不恋水的鱼Single
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     唉，可怜的宝宝，有什么天大的原因一定在丢了，看这个妈妈写了纸条，也是很爱这个孩子的，为什么一定要丢了，再苦再累也不要把这么小的娃遗弃呀，多可；生养一岁多了，感情都舍不得，可怜的小宝宝
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>