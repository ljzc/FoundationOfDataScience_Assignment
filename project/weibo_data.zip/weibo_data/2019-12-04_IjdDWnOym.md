<html>
 <body>
  <h1 id="title">
   #奥运入场式顺序重大调整##奥运入场式顺序重大调整#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-04
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjdDWnOym">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 74
   </li>
   <li id_no="comment_number">
    评论数量： 65
   </li>
   <li id_no="attitude">
    赞： 364
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【国际奥委会：#奥运入场式顺序重大调整#】国际奥委会执行委员会3日通过决定，已获未来奥运会举办权的国家或地区代表团将排在当届东道主之前出场
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     这意味着，明年东京奥运会开幕式上，最后三个入场的代表团将依次是美国（2028年洛杉矶奥运会）、法国（2024年巴黎奥运会）和日本。此外，难民代表团将在希腊后，第二个走入体育场。（新华社）国际奥委会将对奥运会入场式顺序进行重大调整
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     公考指南Afun
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 69
     </li>
    </div>
    <p id="comment_content">
     难民代表团
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     Z樂-宅
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 37
     </li>
    </div>
    <p id="comment_content">
     难民代表团的根源有很大一部分是米国造成的吧
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     双鱼座跟拖延症势不两立-cufe
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 18
     </li>
    </div>
    <p id="comment_content">
     我觉得不论美国排在第几个，都应该让难民代表团排在美国前面入场
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     传说中的女网警
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     #女网警说#国际奥委会：#奥运入场式顺序重大调整#
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     沪漂印象
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     有幸参与了发布会
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>