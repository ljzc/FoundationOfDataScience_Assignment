<html>
 <body>
  <h1 id="title">
   #驾车礼让行人被交警拦下##驾车礼让行人被交警拦下#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-11-29
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IipmAkFsk">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 293
   </li>
   <li id_no="comment_number">
    评论数量： 417
   </li>
   <li id_no="attitude">
    赞： 3510
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【#驾车礼让行人被交警拦下#：你这个行为很严重 要奖励你】25日，新疆乌鲁木齐一驾驶员在斑马线前礼让行人，随后被交警拦下
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     驾驶员被询问时急了，大声质问交警：“还要我怎么礼让行人呢？”交警突然给男子送上礼物：这个行为不错，给你奖励。
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     云等风起
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 455
     </li>
    </div>
    <p id="comment_content">
     看来每个人得到奖励的表现都是一样的，嘿嘿嘿哈哈哈，像个小朋友得到了新玩具，几天都会有好心情，给交通警察👍
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     哦是阿辉啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 234
     </li>
    </div>
    <p id="comment_content">
     大冷天的，尽吓唬人。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     申言臣
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 190
     </li>
    </div>
    <p id="comment_content">
     全场最佳:额还以为尼罚款捏
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-23
    </p>
    <p id="comment_author">
     浪子天涯835
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     哈哈。。。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-23
    </p>
    <p id="comment_author">
     dcsseed
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     吓得人家
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>