<html>
 <body>
  <h1 id="title">
   全国人大外事委员会就美国国会众议院通过“2019年维吾尔人权政策法案”发表声明全国人大外事委员会就美国国会众议院通过“2019年维吾尔人权政策法案”发表声明
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-04
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjbLUijOS">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 123
   </li>
   <li id_no="comment_number">
    评论数量： 245
   </li>
   <li id_no="attitude">
    赞： 1132
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【全国政协外事委员会：美通过涉疆法案是为恐怖主义张目】全国人大外事委员会4日就美国国会众议院通过“2019年维吾尔人权政策法案”发表声明，声明如下：　　当地时间12月3日，美国国会众议院通过“2019年维吾尔人权政策法案”，恶毒攻击中国新疆的人权状况，歪曲抹黑中国去极端化和打击恐怖主义的努力，无端指责中国政府治疆政策，粗暴干涉中国内政
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     我们对此表示强烈愤慨和坚决反对。　　在新疆维吾尔自治区设立职业技能教育培训中心，开展职业技能教育培训工作，是根据中华人民共和国国家安全法、刑法、刑事诉讼法、反恐怖主义法和宗教事务条例，以及《新疆维吾尔自治区实施〈中华人民共和国反恐怖主义法〉办法》《新疆维吾尔自治区去极端化条例》等法律法规设立和实施的。新疆教培中心的设立和实施，目的是消除恐怖主义、宗教极端主义滋生和蔓延的土壤和条件，有效遏制恐怖活动多发、频发势头，最大限度地保障各族人民的生命权、健康权、发展权。这是对广大人民人权的最好保护，也是对国际反恐事业的重大贡献。　　恐怖主义、极端主义是人类社会的公敌。反恐、去极端化是国际社会的共同责任。事实证明，中方有关举措是有效的，新疆治安状况明显好转，已连续三年未发生暴恐案件。然而令人遗憾的是，美国国会不但对新疆依法依规打击恐怖主义、保护人权的努力视而不见，对新疆当前经济发展、社会稳定、民族团结、宗教和谐的大好局面视而不见，反而捏造事实、诋毁抹黑中国反恐和去极端化的正义之举。这是在反恐问题上典型的双重标准，其在人权问题上的虚伪暴露无遗。　　我们坚决反对任何外部势力借人权问题干涉中国内政。我们强烈敦促美国国会摒弃政治偏见，放弃对中方施压的错误做法，停止对中方的无端指责，停止干涉中国内政，停止为中美关系发展和双方在反恐问题上的合作设置障碍。（新华社）全国人大外事委员会就美国国会众议院通过“2019年维吾尔人权政策法案”发表声明
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     尼奇窝窝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 148
     </li>
    </div>
    <p id="comment_content">
     我们宿舍，还有联谊宿舍刚刚全体举手表决，支持加州人民独立诉求方案
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     -Xuekrat
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 157
     </li>
    </div>
    <p id="comment_content">
     我是中国新疆的维吾尔族   我表示我听中国的❤
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-09
    </p>
    <p id="comment_author">
     一只zero吖
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@-Xuekrat:新疆汉族报道
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-08
    </p>
    <p id="comment_author">
     别一口吃掉泡芙
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     我只听中国的！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-08
    </p>
    <p id="comment_author">
     呼庚呼癸5
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     我们家的狗子举爪表决通过美国各州独立法案
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>