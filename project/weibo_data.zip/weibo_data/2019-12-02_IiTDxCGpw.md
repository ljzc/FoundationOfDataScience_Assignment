<html>
 <body>
  <h1 id="title">
   #工信部约谈18家移动转售企业##工信部约谈18家移动转售企业#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-02
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IiTDxCGpw">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 57
   </li>
   <li id_no="comment_number">
    评论数量： 173
   </li>
   <li id_no="attitude">
    赞： 593
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【垃圾信息扰民，#工信部约谈18家移动转售企业#】#垃圾信息泛滥如何治理#近日，工信部信息通信管理局针对部分移动转售企业垃圾信息严重扰民，集体约谈了小米、迪信通等18家移动转售企业，工信部：部分移动转售企业罔顾企业主体责任，漠视用户利益，治理垃圾信息不力
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     （工信部）http://t.cn/Aignn2I7
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     隔壁家的王蜀黍w
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 86
     </li>
    </div>
    <p id="comment_content">
     笑了，不约谈那三个厂商约谈这些，我不用小米我垃圾短信一样多
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     医美小卖部-
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 33
     </li>
    </div>
    <p id="comment_content">
     天天收到的信息:澳门性gan荷官在线发牌
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-07
    </p>
    <p id="comment_author">
     你是我的理想型CoC
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     我根本没点开过什么咪咕视频连app都没装结果就给我弄了一个增值业务  我真的不知道钱哪里扣的莫名其妙的  还有一些老人根本不知道自己办什么业务电话销售打过去就给他们捆绑了业务他们什么都不知道经常说关爱老人对于上了年级的老年人是不是限制一下电话销售呢？如果他们是你们的父母呢换位思考
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     胖曲奇奇奇
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     支持
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     yuern
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     感谢感谢太感谢有人管了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>