<html>
 <body>
  <h1 id="title">
   #暴恐父亲强迫六岁儿子开枪##暴恐父亲强迫六岁儿子开枪#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-08
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjNSZaDxi">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 360
   </li>
   <li id_no="comment_number">
    评论数量： 180
   </li>
   <li id_no="attitude">
    赞： 1673
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【新疆暴恐幕后黑手 当6岁男孩扣动扳机】2010年流出的一段视频中，“东伊运”展示了儿童使用遥控装置引爆带“中国警察”字样的车辆模型
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     成员肉孜洪拉的手机里的一段视频中，#暴恐父亲强迫六岁儿子开枪#，儿子拒绝无效，最终按照他的要求扣动了扳机。枪声响起，小男孩嚎啕大哭…CGTN的微博视频
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-08
    </p>
    <p id="comment_author">
     尼奇窝窝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 351
     </li>
    </div>
    <p id="comment_content">
     祖国真的太不容易了，内患外扰，一不侵略，二不扩张，三不殖民它国、全靠人民的艰苦奋斗，还处处被打压，国家兴亡，匹夫有责！外部势力一直在新疆、香港多方式分裂、破坏，颠覆、渗透洗脑年青人，真的比邪教还可怕！为了遏制中国发展、阴谋诡计真的无所不用其极分裂我们国家，帝国主灭我之心不死
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-08
    </p>
    <p id="comment_author">
     少年vivi爱吃小樱桃
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 162
     </li>
    </div>
    <p id="comment_content">
     宣传口来高人了吧？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-08
    </p>
    <p id="comment_author">
     我在天涯啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 108
     </li>
    </div>
    <p id="comment_content">
     美国搞不乱香港又来搞新疆，疆独有了美国的支持会更嚣张
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-13
    </p>
    <p id="comment_author">
     longGiabiconi
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@我在天涯啊:香港只是在内地 平息 而已
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-10
    </p>
    <p id="comment_author">
     SUN晴晴晴
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@大明南直隶总督:没有的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-10
    </p>
    <p id="comment_author">
     尤里格里高里耶维奇
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@少年vivi爱吃小樱桃:高不高不知道，只是原来的太渣。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>