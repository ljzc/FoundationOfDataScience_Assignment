<html>
 <body>
  <h1 id="title">
   #浙江卫视回应高以翔死因##浙江卫视回应高以翔死因#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-11-29
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IisNUhGlX">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 1265
   </li>
   <li id_no="comment_number">
    评论数量： 1007
   </li>
   <li id_no="attitude">
    赞： 7143
   </li>
   <li id_no="target">
    疫情相关： True
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     【#浙江卫视回应高以翔死因# 医院：心源性猝死】今日，浙江卫视《追我吧》发布声明表示，11月27日在节目录制中，高以翔奔跑时突然减速倒地，经过医护人员全力抢救，医院最终宣布高以翔心源性猝死
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     节目组正协同其经纪团队联系其家人共同妥善处理善后事宜。
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     猫爪上的草履虫
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 787
     </li>
    </div>
    <p id="comment_content">
     这是人祸...
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     医美小卖部-
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 559
     </li>
    </div>
    <p id="comment_content">
     最生气的是到现在为止没有一句正式的对不起……
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     湖畔玫瑰
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 490
     </li>
    </div>
    <p id="comment_content">
     人死了，连句道歉都没有，还有这个，蓝台算人吗？ 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-24
    </p>
    <p id="comment_author">
     守廷兔兔
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     觉得第一时间抢救了，拿证明出来啊！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-09
    </p>
    <p id="comment_author">
     暴走小短腿ing
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     #二十问浙江卫视#
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-09
    </p>
    <p id="comment_author">
     发水面包Cc
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     //@人民网:【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件，暴露出高强度吸睛、轻安全保障等真人秀综艺节目行业性问题，到了需要审视反思时候了。没有必然的隐患，就会少一些偶然的悲剧。当制作方与明星陷入彼此需要又相互消耗的循环时，双方已无力打破畸形闭环，需要外力干预传媒锐评：拒绝行业病态发展 让″高以翔们″放心飞翔
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-08
    </p>
    <p id="comment_author">
     丫--G
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     人去世了节目组还骂人，避重就轻的回答问题
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-08
    </p>
    <p id="comment_author">
     爱上爱琴海的你
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     哎，你这是说了个啥嘛，就是高以翔的死不一定是zjws的锅？我完全没看出来您们为高以翔做了什么，请不要再给zjws 洗白了。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-06
    </p>
    <p id="comment_author">
     润宝1127
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     重点在失救啊
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     微凉wd
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     跟行业没有多大关系，根本原因就是节目组的过失！//@人民网:【传媒传媒锐评：拒绝行业病态发展 让″高以翔们″放心飞翔
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     抚州小万
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     可以报警立案什么的吗，微博终究只是个娱乐软件吧
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     妳超甜的可爱多女孩
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     //@人民网:高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。没有必然的隐患，就会少一些偶然的悲剧。当制作方与明星陷入彼此需要又相互消耗的循环时，双方已无力打破畸形闭环，需要外力干预。传媒锐评：拒绝行业病态发展 让″高以翔们″放心飞翔
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     张若秋YOYO
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     夜里录节目是因为艺人档期不懂？那内些白天录的节目都是咋录的？那些节目档期咋就能同呢？夜间录节目不过是想录制过程不要被太多路人看到而已。只是为了节目组、电视台的利益而已。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     思小女
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这是人祸
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     楚荷衣爱宝宝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@猫爪上的草履虫:明知道是高难度的挑战节目，难道不应该配备两名急救医生吗？咱们家里日常还会备退烧药创可贴感冒药绷带，况且是如此高难度的挑战，还是夜间，连轴转工作的情况下？配医生很难吗？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     蓉耀时光
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     是人祸！官媒发声也没有办法整治浙江卫视吗？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     Viana112
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     //@人民网:【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。没有必然的隐患，就会少一些偶然的悲剧。当制作方与明星陷入彼此需要又相互消耗的循环时，双方已无力打破畸形闭环，需要外力干预。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     轻若清雨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     第一时间抢救了吗
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     轻若清雨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     偏题了，黄金4分钟是有机会救活的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     EVA迦
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这不是什么娱乐不是粉丝偶像不是什么炒作这是一条命，草菅人命啊，你配冠以中国蓝吗？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     易只迷人的火羊宝宝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     都是做媒体的，就想替蓝台说句话？这！是！人！祸！是完全可以避免的！搞清楚好吗！别转移视线了！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     Waitingfly
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     降低片酬，这样艺人就不用这么赶档期，赶片场，把💰 花在安全措施和医疗器械配备上！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-03
    </p>
    <p id="comment_author">
     饭米粒in北京
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     @搭達打大大絕絕：行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法！ 资本万恶 可以一手遮天 但我选择抵制蓝台 浙江卫视一生黑
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-03
    </p>
    <p id="comment_author">
     Happiness027
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     确实是时候了，在我们国家，岂能任资本戏谑人命，必须遏制此等歪风邪气，从根本上杜绝。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-03
    </p>
    <p id="comment_author">
     俏皮话Sally
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@我猜你猜不着猜:说的句句在理，一针见血
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     调皮梦话宝贝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     讲的好
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     西了个瓜吆
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     现在这是转移视线吗
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     琴鹤上人
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     这是人祸，，蓝台有不可推卸的责任，唯利是图娱乐至死压榨劳力，
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     Sa玲
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     浙江台不该出来跪错吗！人命啊
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     s_z夏陌
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@weepyjester_:很硬的靠山，央视台长就是浙江的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     s_z夏陌
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     请浙江卫视还原事发的真实过程，曝光全程，不要企图掩盖，苹果新闻网直播中，媒体说专机200万台币，客机10万台币。钱都拿去撤热搜了？最起码的体面都不给，无常
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     分出两半的子爵Violet
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     你真是愧对了你的名字
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     分出两半的子爵Violet
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     你在吃血馒头
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     斓蓝在此
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     这篇锐评写的不好！受害人尸骨未寒，不了解事情真相的时候就发表所谓权威评论！不算严谨！不合时宜！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     Regina萌不过Ata成不了Amy
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     //@人民网: 【拒绝行业病态发展】高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。没有必然的隐患，就会少一些偶然的悲剧。当制作方与明星陷入彼此需要又相互消耗的循环时，双方已无力打破畸形闭环，需要外力干预。 传媒锐评：拒绝行业病态发展 让″高以翔们″放心飞翔
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     mingyue_annie
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     如果不打官司的话 是不是就只有网友对节目组在微博上的语言谴责了？当时的视频细节就石沉大海了？是啊，协助后事、赔钱安抚，就可以抵罪了，就可以杀人了。中国不需要真相大白，大众不需要也不允许有知情权，过好自己的日子算了。可怕 可悲 心痛啊！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-01
    </p>
    <p id="comment_author">
     一只不爱奶茶的坦坦
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     高先生这件事之后，微博上出现过的其他热搜我都不再感兴趣。只求这个世界能还他一个公道。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-01
    </p>
    <p id="comment_author">
     神神叨叨夜猫子坏猪头
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。没有必然的隐患，就会少一些偶然的悲剧。当制作方与明星陷入彼此需要又相互消耗的循环时，双方已无力打破畸形闭环，需要外力干预。@人民日报 @央视新闻
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-01
    </p>
    <p id="comment_author">
     奔跑的烤排骨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     每年监狱民警过劳猝死的有多少，现在有几个监狱配备了相应的急救设备，整天变着法的给犯人改善条件，还给装中央空调，大学宿舍有中央空调吗？罪犯反正享受了。保障罪犯的基本人权是没错，但是不能超出一定的限度吧？考虑过受害者家属的感受吗？而且当惩罚机关失去了惩罚效力，是不是在变相鼓励犯罪？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-01
    </p>
    <p id="comment_author">
     下雨的海-
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     //@人民网:【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件 暴露出的高强度吸睛 轻安全保障等真人秀综艺节目的行业性问题 到了需要审视反思的时候了 没有必然的隐患 就会少一些偶然的悲剧 当制作方与明星陷入彼此需要又相互消耗的循环时 双方已无力打破畸形闭环 需要外力干预。传媒锐评：拒绝行业病态发展 让″高以翔们″放心飞翔
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     -叶玮-
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     //@人民网:【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。没有必然的隐患，就会少一些偶然的悲剧。当制作方与明星陷入彼此需要又相互消耗的循环时，双方已无力打破畸形闭环，需要外力干预。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     不允许改昵称了
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     浙江卫视节目组太不要脸了，希望国家有关部门给予封杀
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     豆子青春
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     涉事平台卫视在事故发生后不作为不担当，还把明星艺人当遮羞布，拉无良营销号出来扰乱视听，请还明星艺人一个公正！！！//@人民网:【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     寻na启示
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@独立供暖好的呀:第一个发高危职业的人不是壹心的艺人第一个发那张图的是个导演壹心被拉出来垫背了（主要杨天真给路人留下了太多不好印象所以营销号一开始说壹心的艺人就都信了）
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     月半jiojio
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     只要抢救及时，获救率高达90%！而AED就在300米内，跑步往返时间至多2分钟！只因节目组前期勘察不到位，对必要知情信息不了解，导致高以翔错失黄金4min抢救时间而逝世的悲剧，浙江卫视难辞其咎！#高以翔老板发文# #高以翔抢救现场视频#
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     幸运弹2000020
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     #高以翔抢救现场视频# 高强度吸睛，轻安全保障！//@人民网:【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。没有必然的隐患，就会少一些偶然的悲剧。传媒锐评：拒绝行业病态发展 让″高以翔们″放心飞翔
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     Daily87981
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     蓝台彻底糊，坚决抵制，一生黑，问责也应该从上而下，一条线，去他的，好意思说第一时间，都在想模糊话题，转移话题，坚决不被带着走，释小龙之前的助理的事也了解下，蓝台不是一回了，高危行业多了，难道我就不工作了，拳击高危吧，人家不也挺好的，别扯有的没的，人倒了还节目效果，几分钟没人理
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     钱芥蓝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     你不就拥有这个外力的能力，来吧
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     Juliet琻琻
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这是浙江台全体工作人员造成过失死！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     啦啦啦贼6
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     #高以翔抢救现场视频#  为什么
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     rachelisnotsook
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     @Sue-0727
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     rachelisnotsook
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     抢救不及时！！还原真相
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     束发的记忆i
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     不过是踩在死人的骨头上炒热度，因为这个大家都去看了那个节目，不是吗？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     柠檬wu-APPLE
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     工作人员的冷漠，害了一个年轻人，为了拍出惨的效果，把艺人的生命放于什么位置？医护人员哪怕早到两分钟，结局都不是这样的，到现在节目组还在推卸责任，心源性心脏病居然成为了挡箭牌。为什么没有反思自己在做这档节目时，存在哪些安全隐患，为什么人死了一句道歉都没有。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     O宇宙的尽头O
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     回复@致我们:省台无法撼动，痛心！！人民都失望了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     蜜莉呀
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     哎…希望很多行业都能不过劳不病态地发展，希望AED能更普及
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     -大白兔奶糖-y
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@敷尔佳吖-:大家对生命的逝去都会感到惋惜的，但是高以翔先生，不是过劳死，是过失死。 更多的是气愤，浙江卫视火了一个跑男就想把所有节目都设置成极速运动类，寒冷的冬天连夜录制运动类节目，本身就不合理，要做这样的节目却省钱不配专业医疗团队和仪器？？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     -大白兔奶糖-y
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     大家对生命的逝去都会感到惋惜的，但是高以翔先生，不是过劳死，是过失死。 更多的是气愤，浙江卫视火了一个跑男就想把所有节目都设置成极速运动类，寒冷的冬天连夜录制运动类节目，本身就不合理，要做这样的节目却省钱不配专业医疗团队和仪器？？？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     -大白兔奶糖-y
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@猫爪上的草履虫:“何为人血馒头。你同学因为电风扇掉下来砸中头部没得到及时救助当场死亡。这个时候你不去安慰他家人亲属，不去问责学校为什么不排除安全隐患。哭爹喊娘的叫学校给你宿舍装上空调冰棍无间断供应。 这个时候，哪怕闭嘴无视，也更有人情味得多！”
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     -大白兔奶糖-y
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     “何为人血馒头。你同学因为电风扇掉下来砸中头部没得到及时救助当场死亡。这个时候你不去安慰他家人亲属，不去问责学校为什么不排除安全隐患。哭爹喊娘的叫学校给你宿舍装上空调冰棍无间断供应。 这个时候，哪怕闭嘴无视，也更有人情味得多。”
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     _小k萝卜_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     天哪
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     媒准
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@-Tangerine916-:公司员工996猝死了，你也怪公司？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     媒准
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     回复@猫爪上的草履虫:都是一群深井冰！滚可以吗！不要来玷污人民网的客观！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     病态萌感
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     既然要拍高强度综艺，就应该把安全保障做足，既想赚钱，又不想做好安全预算，这不是恰脏钱吗？不具体谈某一个电视台的责任，而泛化到整个行业来谈高强度工作，这不是转移焦点吗？反思行业应该是在浙江卫视给出跟拍录像之后，才做的事情，而不是在这次问题还没解决的时候就提出来，强化人们的无力感。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     步履不停ing12
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     请问浙江卫视第一时间抢救了吗？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     宁宇公子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     其实观众并没有很喜欢这种节目
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     夏目友人帐90
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     和稀泥
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     夏目友人帐90
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     行业乱象确实存在。但！高以翔死了。不是应该先调查真相吗？这个是个活生生的生命啊！！！！！就是石头，掉水里，也有个水花吧。都怎么了？现在人死了，谁的过错一个也没说清楚？就一个行业乱象不了了之？这个世道怎么了？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     tossdoy孙一锋
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@YT7654321:如果一样的话为什么没人联系在一起呢？说明是不一样还是没人知道呢？为什么不一样，不一样在哪呢？又或者为什么微博大家都不知道呢
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     阿鉧吶鉧
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@李小兜:公关广告行业赶上急案连续四十小时不下班不在少数，你见到设计身边坐着医生？你见到策划旁边坐着大夫？你见到公司楼下停着120？我只见过他们猝死的新闻，却没有你们这样的孝子贤孙跟着哭天抢地。人都是平等的，除非你是老高家二奶生的野种，那我理解。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     抹茶三分甜O_o
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     可即便是病因性猝死 在黄金时间内抢救 也有90%的概率救活不是吗？？？ 查看图片 //@人民网:【传媒锐评：拒绝行业病态发展】当制作方与明星陷入彼此需要又相互消耗的循环时，双方已无力打破畸形闭环，需要外力干预。传媒锐评：拒绝行业病态发展 让″高以翔们″放心飞翔
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     每天都想减肥的Fiona
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     并不够客观
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     绿箩花妞妞
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     栏目不应该反思吗？艺人和经纪人同样要反思，作为艺人和经纪人，把工作排满或许确实如此，身不由己，不过天下的事情还是不要穷尽一切去完成，毕竟生命就这一次，失去不会重来。愿世人彼此珍惜，愿逝者安息。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     LL喜欢你呀
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     如果第一时间救治的话可能他已经高高兴兴回家了，而不是躺在一个冰凉的车里被运回家……
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     墙里秋千墙-外道
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这个写的客观//@人民网:【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。没有必然的隐患，就会少一些偶然的悲剧。当制作方与明星陷入彼此需要又相互消耗的循环时，双方已无力打破畸形传媒锐评：拒绝行业病态发展 让″高以翔们″放心飞翔
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     沃錀Warren
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     有个地方的人是真奸，毕竟是商人太多
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     池木绅傑
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     一次人命是意外，二次人命是巧合，烧高香求浙江卫视事不过三。不然凉的不是嘉宾的尸体，而是广大观众寄寓厚望的心
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     夜太深了
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     别扯行业，这就是浙江卫视的锅，这几年因为节目毫无安全意识导致的死亡有几起？或者危及生命安全事故有几起？而且这次浙江卫视的处置善后手段，几乎到了冷血的地步，先让浙江卫视成为典例，就当法律上不能怎么样，也要让其在舆论中受到该有批评，让其名誉付出代价，而不是轻飘飘一句行业有问题就完了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     梳格落笛
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     #抵制浙江卫视# #浙江卫视出来道歉#
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     阁下早安
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     现在看这个噩耗，还是觉得好玄幻……感觉像是，他在一部剧里的角色去世了，仅此而已。而现实世界里，他还好好活着…… 我并不是他的粉丝，但是生命的脆弱，还是让人唏嘘。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     韬小韬的幸福时光
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     是人祸
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     李小兜啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@瀬奈啾啾:对自己老板怕不是屁都不敢放，就只敢怼网友呢
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     嗷呜嗷呜嗷呜困
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     回复@湖畔玫瑰:还有一个工作人员在后援会的wb底下骂他们。。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     啾啾兔啦
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@李小兜:害，这种就是资本最喜欢的的乖乖听话的劳动力辣！明明同为被剥削者还会窝里搞内讧呢，资本可省事可开心啦。不必跟他生气，在他们眼里你薪水不是最低的就没资格说话，没资格维权。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     一颗糖lx
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     //@人民网 :【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。没有必然的隐患，就会少一些偶然的悲剧。当制作方与明星陷入彼此需要又相互消耗的循环时，双方已无力打破畸形闭环，需要外力干预。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     梦子锅哩
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@西北山口久美子:这位观众也需要心理疏导啊 看着一个人这么离去  浙江卫视biss
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     李小兜啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     回复@阿鉧吶鉧:还有啊，我麻烦你搞清楚，这种高强度节目录制现场，保险和医疗是法律规定必须配备的东西，缺一不可。法盲简直是。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     李小兜啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     回复@阿鉧吶鉧:为了钱就应该送命？您这脑洞好大唉。意思是你老板跟你签约，你为他工作，你也该送命咯，你不也是为了钱吗？他的钱是多，多就可以多到把命送了的地步？真搞笑啊，那你老板觉得给你的钱多了，你应该多工作，是不是也需要你去送命啊？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     彭冠英什么时候来娶我0123
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     浙江卫视弄出的人命没人能管吗????！球球了！管管吧！给所有人一个交代！！！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     阿鉧吶鉧
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@李小兜:请问哪一位参赛明星是被绑过去参加的？哪位又不是为了钱？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     明月Geo我心
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     @浙江卫视中国蓝 无良电视台
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     皮卡丘咔皮
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     回复@猫爪上的草履虫:行业整改和为高以翔讨说法又不矛盾，干嘛老在那儿说什么避重就轻？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     李小兜啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@阿鉧吶鉧:那种运动员都受不了的高强度节目录制，是需要并且规定必须配备医疗救助的，你不懂没关系，现在告诉你，知道还来得及，别杠了。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     阿鉧吶鉧
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@李小兜:看来您每天拉屎的时候都得肩膀扛俩医护人员啊。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     XC啊YKK
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     #追我吧本周停播# #高以翔粉丝诉求# @浙江卫视中国蓝 正面道歉承担起责任 做个人吧//@人民网 :【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。没有必然的隐患 就会少一些偶然的悲剧http://t.cn/AigXpLN
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     阿鉧吶鉧
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@一定要去安娜堡的我:希望您死得别这么潦草，到时候您先截肢，然后植物人躺十年再死。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     臭臭_踩funghi的小姑凉
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这是人祸，麻烦跟进，严惩浙江卫视
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     啾啾兔啦
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     回复@敷尔佳吖-:有些人啊，一味的嫉妒掩盖了所有人性。有没有想过这还是有关注度的艺人，在那么多人的眼皮底下，摄像机底下维权都这么难了，有没有想过如果需要维权的是自己呢？如果是自己相关的人呢？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     李小兜啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     回复@阿鉧吶鉧:不好意思，没兴趣玩儿游戏，只知道一个大活人，在濒危的时候必备的医疗救助没有到位。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     豆子老头儿
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     建议停业整改
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     阿鉧吶鉧
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@欲为家的木rrr:正在做，而且比您做的到位！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     阿鉧吶鉧
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@李小兜:没听说过，王者农药出了三款黄金圣斗士皮肤了，买了之后每局该死也死。这事儿跟黄金不黄金的没关系，主要是看装备是不是六神。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     阿鉧吶鉧
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@星空201006:比您像人
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     阿鉧吶鉧
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@夏洛克-福尔魔浩:我们出不了，谢谢！要出您出吧！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     啵姐最爱腊八蒜
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     该整顿了！！//@人民网:【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。当制作方与明星陷入彼此需要又相互消耗的循环时，双方已无力打破畸形闭环，需要外力干预。传媒锐评：拒绝行业病态发展 让″高以翔们″放心飞翔
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     柚子不皮要加油
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     //@人民网:【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。没有必然的隐患，就会少一些偶然的悲剧。需要外力干预。传媒锐评：拒绝行业病态发展 让″高以翔们″放心飞翔
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     baby佐小猪
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     好惋惜就这样离开了，希望电视台给出一个交代，看来好难
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     Miracle_aaa
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     真的非常心痛
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     进击的onion
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     资源垄断让某些人眼里只有钱，没有人!
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     进击的onion
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@在云的脚下:媒体垄断!!
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     长夏季的千寻
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     病态的行业太多……
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     噼里啪啦彩虹糖85
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     //@人民网:【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。没有必然的隐患，就会少一些偶然的悲剧。当制作方与明星陷入彼此需要又相互消耗的循环时，双方已无力打破畸形闭环，需要外力干预！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     叶文欣Karlin
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     #追我吧本周停播# #高以翔粉丝诉求# //@人民网:【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。没有必然的隐患，就会少一些偶然的悲剧。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     进击的onion
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     问责问责!!!
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     追光者两陷
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     这种玩弄人命的综艺我真的不爱看，也真的不吸睛，我甚至不能理解这档综艺存在的意义到底是什么，电视台播出节目的意义应该怎样？仅仅是娱乐至上么？？？这种玩弄性命在生死边缘来回试探的节目，我觉得根本没有存在的必要，它会误导心智还未成熟的青少年！难道还要再多几条人命才会有人关注整改么！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     秋桐童装
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     生死是天注定的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     胃夫人upup
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@记住我是个男人:我诉求电视台高层问责公开道歉处罚，因为不令最上层感到切身痛，人命在他们眼中仍然不值钱…
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     胃夫人upup
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     我诉求电视台高层问责公开道歉处罚，因为不令最上层感到切身痛，人命在他们眼中仍然不值钱。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     胃夫人upup
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     这么好的高以翔，不会再回来了，之前出现过多少的安全隐患，浙江卫视追我吧都没有做出改变措施，反是变成合同上的“免责声明”，之前死过人的，浙卫高层对生命的冷漠，或许才造出了层出不断的安全事故。作为媒体，传播的东西是有影响力的，追我吧浙江卫视传播的又是什么内容？恐慌？行业的病态发展心寒
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     沁069
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@海上月糹:顶上去
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     沁069
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@音乐精选榜:没有第一时间抢救 而且发现高以翔倒下的时候还以为是节目效果继续拍摄 活生生错过抢救时间😡😡
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     金鱼庄庄
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     沁069
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@wahgykr5yxjf:顶上去
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     金鱼庄庄
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     我们拒绝下一个高高，要浙江台一个真相，不要给我们珍爱的高高抹黑，逝者安息请不要让逝者为他自己的离开背锅@浙江卫视中国蓝 http://t.cn/AigSar3z
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     鸢久y
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@马克1号:哎撇开钱不说就这个解决问题的方式浙江卫视真的不行
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     沁069
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@西北山口久美子:图片评论 http://t.cn/AigSXHvl
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     沁069
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@西北山口久美子:没错 就是浙江台没有及时救治造成的！事后还试图转移群众视线洗白！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     沁069
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@尼奇窝窝:图片评论 http://t.cn/AigSXbfz
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     沁069
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@冲浪啊冲浪啊:图片评论 http://t.cn/AigS6ByO
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     追光者两陷
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，需要完整的责任安全明细报告
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     easy1180
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     如不整改，这么优秀的一个人的离开将变得毫无意义
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     慕言zhi澈
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     大众并不是放大明星效应，很多人或许都不认识高先生，大众愤难平的是一手遮天的不公，蓝台一而再爆出明星录节目受伤，居然没有被重视，大众讨伐的是态度问题，电视作为传播正能量与观众每天息息相关的媒体，一条人命换不来蓝台一个真诚公开的道歉。整个细节我们无从得知,但人家确实是在录节目中逝去。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     easy1180
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@大叔的青春年华哈:所以需要有人站出来发声
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     喝了这杯珍珠奶茶
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     水产什么时候死绝什么时候改名
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     重要的不是这个，是节目组到底有没有医护人员，有没有立刻救治
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     麓噜
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@致我们:不能任它们无法无天
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     花狸52299
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     太没担当了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     麓噜
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     回复@冲浪啊冲浪啊:人不救，第一时间撤热搜
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     麓噜
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     回复@湖畔玫瑰:浙江台真的没有心
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     Sobremesa_19
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     #高以翔好友婚礼 彩虹# #节目组要求现场观众签保密协议#
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     全场最佳暗恋王
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     按照月薪一万来计算片酬，也就没有那么多无病呻吟了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     夏寂微雨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@数字公区:怎么没关注？家人就有跑马拉松的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     诸囧囧
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     //@人民网:高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。没有必然的隐患，就会少一些偶然的悲剧。当制作方与明星陷入彼此需要又相互消耗的循环时，双方已无力打破畸形闭环，需要外力干预。传媒锐评：拒绝行业病态发展 让″高以翔们″放心飞翔
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     嘉小民
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@YT7654321:就是压榨员工，利益至上，最后还把人家踢了，太可怕了！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     努力赚钱的小梁
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这个电视台安全问题不过关造成的人命！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     嘉小民
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@wahgykr5yxjf:上去，建议艾特人民日报，半月谈，央视新闻！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     我是恬恬丫恬恬
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     回复@湖畔玫瑰:@人民网
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     我是恬恬丫恬恬
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 8
     </li>
    </div>
    <p id="comment_content">
     回复@猫爪上的草履虫:@浙江卫视 @人民网 这是人祸‼️浙江卫视错过抢救最佳时间 本可以救活一条人命 节目组及浙江卫视的不重视 继续录制节目 导致悲剧 并且不还原事故真相 请还我们一个公道
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     公区社
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@夏寂微雨:每年跑马拉松都死人，每年都举行，你关注了吗？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     zxxbeing
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     高以翔不是过劳致死，是过失致死啊，节目组设置游戏环节高强度高难度，又没有相应的安全和急救措施，事后更是一句道歉都懒得说。现场观众发声被删博销号，粉丝组织追悼被强行驱离，有关事件的评论被转为自己可见，热搜话题直降。人命就这么轻飘飘吗？求求大家别放弃他
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     咕噜咕噜Yahooo
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     他们没救好吧都是装样子
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     冰雪847
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     新的知情人爆料2 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     冰雪847
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     新的知情人爆料 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     绝绝本绝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     节目录制时间这么长，场地范围这么大，医疗保障是否能有效实行？在开始前有没有做过实际救助演练？有无预想遭遇路障等突发情况时如何快速进入救助区进行救助？整个救护过程是否由有资质有救助经验的救护人员来施行救助？从事发到救护人员到达现场经过了多长时间？这些现在都是个谜，我们只想知道真相。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     Ananhalf-
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     浙江卫视太过分了！！！！还我们公道！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     爱追剧的羊咩咩
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     很多时候大多数人也只是想要一句正式的道歉而已，可是两天了，在浙江卫视的公共平台上除了整版推卸责任“甩锅”的言论，我们看不到一句道歉看不到一丝歉意一丝悔意。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     Jeasuer
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     明明高以翔可以不用死的，节目组的过失，导致生命无法挽回，第一时间发的是声明，撇清自己的责任，第三天迫于网上的压力，说会承担责任，期间不停拿各种明星来挡枪，不停撤热搜。承认错误就这么难吗？还死不承认，也不怕同行笑话，看看哪个省台是这样的？？真是丢浙江的脸，全台bisi
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     最苏的玛丽
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     浙江卫视不是娱乐性商业电视台，它的本职工作是国家性的省会电视台，它是人民群众的喉舌，它最重要的职责难道不是传播“真实“的新闻？代表最广大人民群众的心声？这种做法，只会让更多的人质疑，从此以后浙江卫视的新闻是真实的吗？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     _Fresh
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 4
     </li>
    </div>
    <p id="comment_content">
     回复@致我们:@人民网 @央视新闻 @共青团中央 @中国警察网
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     _Fresh
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 7
     </li>
    </div>
    <p id="comment_content">
     回复@-Tangerine916-:浙江卫视两条人命、多次事故 http://t.cn/AigaRLr9
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     _Fresh
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！漠视生命绝不容忍！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     cicibiabia
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     @浙江卫视中国蓝
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     _Fresh
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 7
     </li>
    </div>
    <p id="comment_content">
     回复@猫爪上的草履虫:@人民日报 @共青团中央 @央视新闻 强烈要求公布现场各机位视频！彻查浙江卫视及节目组！省级电视台漠视生命、甚至控制舆论为自己洗白，所作所为及其恶劣！没有人性没有道德的浙江卫视如何为大众传播正能量？如何让社会信服
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     女仙小的柔温
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     外力快介入吧，需要严查了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     秋名山上卖珍珠奶茶
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@夏寂微雨:是啊，明星也不敢发声，毕竟他们不只是代表了自己，还有整个团队。可能他也想发声吧，只是迫于真的压力。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     娜娜与zxj婧
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     浙江台明显抢救不及时，错过了黄金救治时间，这样的真人秀却有如此的纰漏，只在乎能不能拿到让观众紧张刺激的镜头，试问这样的综艺有存在的必要么？可恶的事浙江卫视已经不是第一次犯这样的错误了，却始终无动于衷！如今的真人秀已经成为乱象，急需要整顿，如果可以，请从浙江卫视开始！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     你的锦鲤Girl·带你暴富
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     你们考虑过我们网友的难受和心痛的感受了吗 虽然说我们个人能力微不足道
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     _Fresh
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 7
     </li>
    </div>
    <p id="comment_content">
     回复@猫爪上的草履虫:@人民日报 @共青团中央 @央视新闻 强烈要求公布现场各机位视频！彻查浙江卫视及节目组！省级电视台漠视生命、甚至控制舆论为自己洗白，所作所为及其恶劣！没有人性没有道德的浙江卫视如何为大众传播正能量？如何让社会信服
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     女仙小的柔温
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     外力快介入吧，需要严查了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     秋名山上卖珍珠奶茶
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@夏寂微雨:是啊，明星也不敢发声，毕竟他们不只是代表了自己，还有整个团队。可能他也想发声吧，只是迫于真的压力。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     娜娜与zxj婧
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     浙江台明显抢救不及时，错过了黄金救治时间，这样的真人秀却有如此的纰漏，只在乎能不能拿到让观众紧张刺激的镜头，试问这样的综艺有存在的必要么？可恶的事浙江卫视已经不是第一次犯这样的错误了，却始终无动于衷！如今的真人秀已经成为乱象，急需要整顿，如果可以，请从浙江卫视开始！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     你的锦鲤Girl·带你暴富
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     你们考虑过我们网友的难受和心痛的感受了吗 虽然说我们个人能力微不足道
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     许执意的黄坚持
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     只是想要一个道歉那么难吗
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     vaneyouyim
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     //@猫爪上的草履虫:这是人祸...
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     许执意的黄坚持
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     快介入还家人和粉丝一个公道吧
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     LzOx22
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     你的锦鲤Girl·带你暴富
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     我们观众需要的公布道歉
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     拳昏
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     节目组没有第一时间抢救 并且浙江卫视在多次节目中都曾出现事故 屡教不改 请立案调查 请给予严惩 请不要轻易放过浙江卫视
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     再不要踮脚尖了
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！@浙江卫视中国蓝 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     2026赴一场极光之约
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     所有的偶然之中都有着必然的联系，不管是造成了人血馒头的还是吃人血馒头的都应该有清晰的认知。行业的病态没有谁是能够独善其身的，愿给大众一个交代。此时想放个图片 查看图片
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     李敏8452
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     @人民网浙江卫视 道歉没有，这是人心也没有了吗
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     Rskr
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     不要避重就轻！去他妈的高危行业，明星是高危行业吗？高以翔的死是因为节目组的失误！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     Rskr
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 5
     </li>
    </div>
    <p id="comment_content">
     回复@嫑闹事:你已经被带坑里去了！高以翔的离开是因为节目组不救助及时！明星不是高危行业！我们都很尊敬那些高危行业的人们，但是高以翔这件事不是因为什么高强度工作，重点在节目组！不要避重就轻
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     搭達打大大絕絕
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@搭達打大大絕絕:@人民网
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     搭達打大大絕絕
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 4
     </li>
    </div>
    <p id="comment_content">
     其实大家都知道行业不能病态发展，也没有人说不应该整治。但在此之前，我们更想要得知此次事件的真相。真相不应该被掩盖，到底时间线如何，为什么现在都不出来讲清楚？事情发生两天了，其实很多人想要的除了真相，还有节目组和浙卫真诚的道歉。但是到现在，在声明里没有看到一句对不起！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     神无月远花火
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     半格里半_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     垃圾浙江卫视@浙江卫视中国蓝 @浙江卫视中国蓝 @浙江卫视中国蓝 你们要还有良心的话 滚出来给说法 滚出来道歉 滚出来给高高家人一个真相
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     _秋小乖
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     草菅人命，无法无天！！！希望国家出面好好整治整治！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     Rskr
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     请不要避重就轻！高以翔的离开不是因为什么行业高危！而是因为节目组的失误！因为没有救治及时！！！！！！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     半格里半_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     高以翔不应该走啊
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     半格里半_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     他本不应该走的啊
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     北冰大西洋洋洋
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 6
     </li>
    </div>
    <p id="comment_content">
     回复@只是我的微博昵称:目前所以现场观众分别给不同平台的反馈都一致说是没有的。最气人的是，那四分钟内他周围的工作人员还拿着机器给他拍特写，为了素材，没一个上去看他，是其他嘉宾通过屏幕发现了不对劲才叫来喊人的。医生真正过来的时间是15分钟左右，人都凉透了。。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     Rskr
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     回复@猫爪上的草履虫:不是天灾是人祸！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     Rskr
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     工作人员的冷漠，害了一个年轻人，为了拍出惨的效果，把艺人的生命放于什么位置？医护人员哪怕早到两分钟，结局都不是这样的，到现在节目组还在推卸责任，心源性心脏病居然成为了挡箭牌。为什么没有反思自己在做这档节目时，存在哪些安全隐患，为什么人死了一句道歉都没有。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     拥抱我的涡轮喷射机
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     重点在于 浙江ws失职 不作为 草菅人命 错过抢救时间 不道歉不追责好像没事人一样！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     嫌咸的吃瓜群众
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     🙏🙏🙏🙏
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     G留无计
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     第一天撤热搜，第二天撤热搜，第三天转移视线，就抓住了网民是健忘的过了热度就没事了是吧！永远抵制浙江卫视！！！！如果把撤热搜的速度用在救人上而不是拍特写寻求亮点
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     啊咿嘟嘟嘟rx
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     工作人员的冷漠，害了一个年轻人，为了拍出惨的效果，把艺人的生命放于什么位置？医护人员哪怕早到两分钟，结局都不是这样的，到现在节目组还在推卸责任，心源性心脏病居然成为了挡箭牌。为什么没有反思自己在做这档节目时，存在哪些安全隐患，为什么人死了一句道歉都没有。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     猫和故巷ing
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     现在应该问责电视台和节目组防范和救治措施没做好？！！！错过最佳救援时间！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     大脸飞猪
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     浙江卫视内腐外烂
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     醉梦中的小狐狸
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     公布真相才是对逝者最大的尊重//@人民网:高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。没有必然的隐患，就会少一些偶然的悲剧。当制作方与明星陷入彼此需要又相互消耗的循环时，双方已无力打破畸形闭环，需要外力干预。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     神无月远花火
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     #追我吧本周停播# //@人民网:【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。没有必然的隐患就会少一些偶然的悲剧。当制作方与明星陷入彼此需要又相互消耗的循环时双方已无力打破畸形闭环，需要外力干预。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     5串章鱼丸
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     是！人！祸！！！！听到了没
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     明月Geo我心
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     @浙江卫视中国蓝 无良电视台
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     猪猪家可爱的宝宝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@这是平生呀:
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     猪猪家可爱的宝宝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@这是平生呀:
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     猪猪家可爱的宝宝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     谢谢人民网的发声，我是因为遇见王沥川认识他，了解他却在去世之后
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     掐波肉肉
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     希望这件事情得到重视 浙江卫视得到彻查
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     Allen浅若夏沫
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     行业乱像已成常态，
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     拉普拉斯的五仁
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     没有第一时间抢救，为了综艺效果还在拍摄，没有配备医护人员！这是人祸！浙江卫视公布真相！道歉追责！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     一个大柠檬种子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     浙江卫视那帮人和那帮愤青有啥区别，本质一个样，害死人都无关痛痒
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     三辞Rachel
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@西北山口久美子:太可怕了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     半格里半_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     @浙江卫视中国蓝 不要脸  不作为 他不该走的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     一个大柠檬种子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     浙江卫视高层的后台就有那么大吗？害死了一条人命就无关痛痒的发2个公告，资本力量就那么大？这个社会到底怎么了，真让我们百姓寒心
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     W王小晕Y
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     半格里半_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     @浙江卫视中国蓝 @浙江卫视中国蓝 @浙江卫视中国蓝 滚出来 滚出来给说法垃圾浙江卫视
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     冰雪847
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     浙江广播电视集团事发后至今并未道歉，毫无悔意，控制评论，模糊焦点，甚至意图用高以翔先生自身身体状况有问题脱责。如此没有道德底线，甚至不尊重个体生命，不配作为政府媒体。此外《追我吧》节目组安全保障缺失只是冰山一角，浙江广播电视集团旗下真人秀中艺人安全问题及隐患#追我吧本周停播#
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     亚历山德拉兔
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     生如夏花死如秋叶1798
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     写得好
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     勿语zxy
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     cicibiabia
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     @浙江卫视中国蓝
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     多多多多少少得多多
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     #高以翔好友婚礼 彩虹#
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     三辞Rachel
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     回复@嫑闹事:其实，，，，高以翔经常锻炼身体，身体素质并不差。也请参考拳王邹市明参加这个节目腿抽筋，经常健身的陈伟霆也是直呼参加这个节目最累。所以并不是他身体素质不行，是本身节目设置的强度也比较大，让很多经常锻炼的人都吃不消
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     小jiao0
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     cicibiabia
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     cicibiabia
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     2013到2019一模一样死了人却只想着掩盖过去
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     -智慧树下智慧果
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     图片评论 http://t.cn/AigaNfSj
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     星初浅星鱼
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告@浙江卫视中国蓝
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     圆圆哥哥的江君
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     别提高父母，但凡你们真心想保护他们都该缄口不提这两位。如何承担责任？我想要的是：1、公布现场情况细节，2、公布人事处罚结果和细节，3、高层问责道歉，4、放弃控评公关的举措躺平任嘲，5、制定预防此类事件的举措细节。你们能做到吗？ #节目组要求现场观众签保密协议#
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     ve随缘42108
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这件事的重点一，浙江卫视没有抢救，导致错过黄金时间，造成悲剧。二，浙江卫视没有公布事件视频，还原真相!还死者和家人一个公道和真相!!!
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     啊啊啊哦哦869
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     图片评论 http://t.cn/AigaNqTb
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     若鲁且愚
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     @浙江卫视中国蓝  首先需要真相呈现大众，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告@人民网
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     追光者两陷
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，大众需要事实真相！#追我吧本周停播#
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     吃掉胖年糕
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     是节目组的过失，错过了黄金救援时间。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     0LittleStar0
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     请愿公布最后抢救视频
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     半格里半_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     别想撇清责任@浙江卫视中国蓝 @浙江卫视中国蓝 @浙江卫视中国蓝 @浙江卫视中国蓝 @浙江卫视中国蓝
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     ve随缘42108
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     半格里半_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     @浙江卫视中国蓝 @浙江卫视中国蓝 @浙江卫视中国蓝 垃圾浙江卫视出来受死
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     逆游的小小小小鱼
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这是节目组轻视生命导致的悲剧，我们最想看到的就是制作方相关责任人受到惩罚，需要有人为高以翔的生命买单！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     港岛妹妹咧
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     浙江卫视应该给一个真相
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     我猜你猜不着猜
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     #追我吧本周停播#
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     啊啊啊哦哦869
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     我猜你猜不着猜
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     只喝罐装雪碧
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     学而时习之_highcoldS
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     请求相关监管部门介入！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     雨夜的短腿流浪猫
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     艺人不是高危行业，但每个行业的安全都值得重视，必须重视！希望安全保障措施真正落实到位，希望每个行业的“意外”都能因为安全措施的落实，变成虚惊一场！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     BerryOil
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     哈嗯累了饿了困了
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     我们需要真相
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     杉山而川
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     浙江台隐藏事实#高以翔好友婚礼 彩虹#
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     早川·京子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     如果不是节目组不及时，高高真的可以活下来，高真的是被耽误死了，蓝台还一副事不关己的样子，没有心啊
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     珂尔蜜哆哆
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     小绵羊dadada
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     小绵羊dadada
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     染墨年华柒柒
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     这件事情他们不出来正面道歉正面处理会上升为政治矛盾的，毕竟高高是台湾人，现在港独台独又这么盛行，肯定会抓住这个事情不放的，作为他的家人朋友看到节目组这种态度该多么痛心啊……
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     猪猪家可爱的宝宝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     回复@步绒鸭鸭:意味着根本没有了生的机会，他把他的安全交给了节目组，他信赖每一个人。结果最后
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     mocha_甜甜圈
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     你的大脑瓜子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     猴子酒Lee
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     @浙江卫视中国蓝 进来挨打！！！必须道歉！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     杉山而川
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     早川·京子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     要不是节目组没有及时救治，高高可以不用死的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     ssyoyxis
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 5
     </li>
    </div>
    <p id="comment_content">
     回复@猫爪上的草履虫:@浙江卫视中国蓝 是你没有第一时间抢救
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     学而时习之_highcoldS
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     bia唧一口小奶本
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     请浙江卫视正面回应，还原真相，给逝者家属及粉丝完美的交代。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     是NN啊啊啊啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     节目的设置是否合理,是否考虑到运动强度之大,录制时间的合理安排性,是否提前准备好意外的应急方案,如果连这些都没考虑到那么这件事就不是意外。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     杉山而川
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     浙江卫视必须出来道歉
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     初二初
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     #高以翔好友婚礼 彩虹#
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     你的大脑瓜子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 5
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，需要完整的责任安全明细报告
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     杉山而川
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     节目组没有第一时间抢救。第一时间完全是节目组单方面说辞，毫无证据！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     原来是青争啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。在艺人倒下的第一时间不进行救助竟在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？//@人民网:【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     小jiao0
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     这件事的重点一，浙江卫视没有抢救，导致错过黄金时间，造成悲剧。二，浙江卫视没有公布事件视频，还原真相!还死者和家人一个公道和真相!
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     猪猪家可爱的宝宝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     就因为这必然的安全措施没有了，他的生命没有了任何活着的可能性，那么去世就是必然了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     去给我买汉堡
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     C位让给陆哥哥
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     杉山而川
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     初二初
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，#高以翔好友婚礼 彩虹#
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     GANXIN29
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     丨面丶条
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     是NN啊啊啊啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     这件事完全是因为2台安全设施不到位(甚至是完全没有)，虽然行业也有乱象,但大家不要被转移注意力了!瞄准浙江卫视还有追我吧节目组就对了！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     秋风6245922800
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     浙江卫视还我高高
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     今天脑阔疼了吗_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     乖不如冶
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     一个省级电视台多次发生事故，推脱责任，掩耳盗铃，民众要的只是认真反思，承认错误，娱乐至死的社会里还需要几个牺牲品这种追求奇观的风气才能有所整顿？我们需要刀刃向内的勇气，请拿出一个大台的担当。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     XiaoBD我没有胖嘟嘟
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     //@人民网:【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了，没有必然的隐患就会少一些偶然的悲剧。当制作方与明星陷入彼此需要又相互消耗的循环时双方已无力打破畸形闭环需要外力干预传媒锐评：拒绝行业病态发展 让″高以翔们″放心飞翔
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     八月薄荷味的夏天
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     今天脑阔疼了吗_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     我和蔚梨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     然后他们节目还要继续播
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     猪猪家可爱的宝宝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 4
     </li>
    </div>
    <p id="comment_content">
     回复@敷尔佳吖-:哲学中说偶然中蕴涵必然
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     圆圆哥哥的江君
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     八月薄荷味的夏天
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     八月薄荷味的夏天
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     今天脑阔疼了吗_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     Gezi阁子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的没有及时到位的抢救措施。一个户外大型竞技节目组安全意识竟然如此薄弱//@人民网:【传媒锐评：拒绝行业病态发展】。传媒锐评：拒绝行业病态发展 让″高以翔们″放心飞翔
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     我猜你猜不着猜
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 10
     </li>
    </div>
    <p id="comment_content">
     回复@超麻瓜皮皮鸭:行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     邮寄给星星
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这次我希望互联网是有记忆的 二台biss 推卸责任biss 吃人血馒头的也给爷死 也请昧著良心的那些垃圾抬头看看苍天饶过谁
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     多拉美梦成真
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，但这并不是逃脱责任的理由和借口。节目录制场地是否有生命通道，专业医护是否真的在”第一时间“进行有效抢救，为什么强逼现场观众签”封口协议“。。很多疑虑让人不解甚至不满。而更让人寒心的是节目组甚至一个上星的卫视台处理事情的草率和非专业，希望相关部门严查。#追我吧本周
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     丨面丶条
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@丨面丶条:@人民网
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     我是刘紫依
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     第一时间抢救了吗，黄金四分钟压根没救人
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     丨面丶条
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     只是我的微博昵称
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 8
     </li>
    </div>
    <p id="comment_content">
     回复@湖畔玫瑰:就想问问那个黄金四分钟抢救了吗
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     猪猪家可爱的宝宝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     哲学中说偶然中蕴涵必然
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     一碗Absinthe
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     甜度满分向阳花
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     浙江卫视的不及时抢救导致悲剧 不能容忍这个事就这么混过去！！不要被乱带节奏说什么工作强度熬夜 就是节目组安全意识不够 没有急救应急方案！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     zy过往云烟416
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     难道不能公布救援细节和时间吗，为什么要转移到高危职业？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     只是我的微博昵称
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@湖畔玫瑰:怎么能这样啊
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     只是我的微博昵称
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@湖畔玫瑰:就是啊
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     弗里达女士
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     浙江卫视需要为这次事件负80%的责任 ，没有前期的医疗保障，事件发生依旧冷漠拍摄没有及时救治，事后推卸责任转移焦点。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     一碗Absinthe
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     捋不顺的舌头
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     顶起来
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     FMFIOCassieQ
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     蔑视安全，蔑视生命
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     一碗Absinthe
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     我猜你猜不着猜
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     捋不顺的舌头
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     手机用户阿木
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@搭達打大大絕絕:d
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     手机用户阿木
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 6
     </li>
    </div>
    <p id="comment_content">
     回复@阿鉧吶鉧:这样潦草的死亡你让他怎么安息？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     我猜你猜不着猜
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     啦啦啦贼6
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     zy过往云烟416
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     图片评论 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     逃跑的小豌豆
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     @搭達打大大絕絕: 行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     乖不如冶
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     CHENYIFE
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     手机用户阿木
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     万花筒1982
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     请浙江卫视正面回应问题，不要避重就轻，也请你道歉！！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     捋不顺的舌头
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     跪求人民网要求浙江卫视还大家一个真相
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     福兮祸之所伏c
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     Chuwaso
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     福兮祸之所伏c
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     倩崽要瘦
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     飞鸟与明
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     所以为什么不能给大家一个真相呢，这是一条人命啊
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     倩崽要瘦
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     LilyAhin
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     倩崽要瘦
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     福兮祸之所伏c
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     是NN啊啊啊啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@是NN啊啊啊啊:@人民网
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     是NN啊啊啊啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@是NN啊啊啊啊:#追我吧本周停播#
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     从小妖
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！[
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     凤唳苍穹
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     琴心剑破
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     还我们高高
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     小无敌爱五元
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。//@人民网:【传媒锐评：拒绝行业病态发展】http://t.cn/AigXpLNB
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     是NN啊啊啊啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     逆流而上的鱼和水滴
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     是NN啊啊啊啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     feifeili_L
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     我要吃两个汉堡
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这个节目能不能有点担当！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     哈哈美一天20
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 7
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     刚出锅的油条呀
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     是NN啊啊啊啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     zy过往云烟416
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     Yuyu米粒儿_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     啊咿嘟嘟嘟rx
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     救治不当  保障没有❗ ❗
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     一支绿荷
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     还高以翔一个说法，不能就这么不明不白的走
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     呱瓜瓜
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     恰逢雨连天啊
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     黑夜里清晰的自己
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     夢夢夢夢dream_808
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     @夢夢夢夢dream_808：一堆人搞不懂重點，與論被帶的飛起、大概是失去獨立思考跟查看多方角度看法的能力，真是有夠可悲=.=
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     小无敌爱五元
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄？！//@人民网:传媒锐评：拒绝行业病态发展 让″高以翔们″放心飞翔
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     一支绿荷
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     希望官方介入调查
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     夏寂微雨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@线粒体L:现在各行各业都很病态，好好保重自己吧！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     郁郁不是葱葱
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     图片评论 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     啊咿嘟嘟嘟rx
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     啦啦啦贼6
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     #抵制浙江卫视# #浙江卫视阻拦高以翔粉丝举行追思会#
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     初二初
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     住在自己家的肥肥
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     初二初
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     初二初
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     合萄
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     //@人民网:【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。没有必然的隐患，就会少一些偶然的悲剧。当制作方与明星陷入彼此需要又相互消耗的循环时，双方已无力打破畸形闭环，需要外力干预
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     圆圆的团子团成团
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     查看图片 //@人民网:【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。没有必然的隐患，就会少一些偶然的悲剧。当制作方与明星陷入彼此需要又相互消耗的循环时，双方已无力打破畸形闭环，需要外力干预。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     一木绝不认输
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@欲为家的木rrr:就是这么对待生命的 不好意思漏字了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     Nobodyelse027
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     回复 @嫑闹事:高危职业不是我们说的！！！！是浙江电视台公关部放出来的！！！如果一个明星都因为该有的救援设备不到位，白白死去，普通老百姓谁关心？！。这点基础利益不争取，那你要死了也不会有国家在意救援基础设施完善不完善！！！！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     喜欢豆芽菜呀
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这是浙江卫视害的 医疗措施配备不到位 没有及时抢救 这算天灾？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     嫑闹事
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     回复@_Agj70:我为消防员和农民工赶到不公，也为公务员不公，真正高强度的工作，也因为真正的高强度工作而疲劳致死，收入不高，而一个高收入的明星却因为凌晨作业去世，引起了大家这么多的关注，这是不公的，这不是一句所谓的“难道高以翔死了是应该的？”“高以翔死了就不能引起关注”就能说的通的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     疯比美人
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     太可怜了，明明可以活下来的，那么好一个人，不是粉！我哭到头痛
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     万花筒1982
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     豆豆豆豆豆豆神
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     //@人民网:高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。没有必然的隐患，就会少一些偶然的悲剧。当制作方与明星陷入彼此需要又相互消耗的循环时，双方已无力打破畸形闭环，需要外力干预。传媒锐评：拒绝行业病态发展 让″高以翔们″放心飞翔
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     不吃香蕉只吃蛋卷的猴子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     我们需要真像，二台不要逃避不要退热搜
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     Little0_0Mon
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     明星不合理的高薪酬也是行业病态发展的主因之一
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     __CindyWong
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     夏寂微雨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@春风不婷:@夏寂微雨: 真的，如果连有传播力的明星在遭遇安全事故时都不了了之被资本埋没时，那普通人就更糟糕，完全走投无路了，悲哀
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     不喜欢甜食的Z小姐
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     不吃香蕉只吃蛋卷的猴子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     一木绝不认输
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     我们需要真相
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     Nobodyelse027
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     回复 @嫑闹事:你哪里知道他身体素质不好！！！！我们却有人证视频，证明是浙江电视台救援不到位。没有配套的救援物资和应该在的急救医生！！！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     暴富街芝士广场吃榴莲的杨狗
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@伤心9798:害
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     空山予
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     不吃香蕉只吃蛋卷的猴子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     蓝蓝天空银河里
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     请正面回应//@人民网:【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。没有必然的隐患，就会少一些偶然的悲剧。当制作方与明星陷入彼此需要又相互消耗的循环时，。传媒锐评：拒绝行业病态发展 让″高以翔们″放心飞翔
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     99Streicheln
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     @浙江卫视中国蓝 滚出来
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     空山予
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     暴富街芝士广场吃榴莲的杨狗
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@鎂麗囘憶:你这什么脑回路。拿了钱就该死？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     空山予
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     独钓寒江雪150m
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     27号高以翔先生因为录制追我吧节目倒地不起，离开了爱他的家人以及粉丝。时至此时此刻节目组及平台没有任何道歉。能让我们这么愤怒的原因完全是节目方和平台的冷漠！事件不断被转移视线，不停地被降低热度！我们坚决反对反人类的节目录制强度，要求追我吧节目永久下架！给我们一个结果！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     万花筒1982
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     再不要踮脚尖了
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 4
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告@浙江卫视中国蓝 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     西瓜加鸭脖
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     CHENYIFE
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     七墓凉公子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     西瓜加鸭脖
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     杉山而川
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     夏寂微雨
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     回复@数字公区:如果连有传播力的明星在遭遇安全事故时都不了了之被资本埋没时，那普通人才更糟糕，完全走投无路了，悲哀
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     七墓凉公子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     更重要的是没有根本没有配套的安全保护和医疗措施！本来是可以挽救的，就是因为节目组工作人员在黄金救命时间的漠视和不关心，以及专业医护人员迟迟没有到位，真正导致了这条生命的逝去。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     七墓凉公子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     再不要踮脚尖了
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 5
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！@浙江卫视中国蓝 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     我有些话我要说
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     多么希望“正义也许会迟到，但永远不会缺席”，在这件事情上也是如此，多么希望最后的结果千万不要寒了人心…
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     种花家的大侠
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     恨这个节目
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     叶小小91872
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     请浙江卫视正面回应
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     梳格落笛
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@超麻瓜皮皮鸭:图片评论 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     YT7654321
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复 @tossdoy孙一锋:挺懵逼的  为什么没有人把这两件事联系在一起  其实感觉性质是一样的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     甜甜圈eee
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     为什么要这样对待他，唉，
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     西红柿有点点酸
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     行业乱象由来已久，的确应该深思，但这并不应该成为追我吧节目组和浙江卫视逃脱责任的障眼法。节目录制场地广阔并为节目顺利进行设置路障，使得救护车无法及时到达展开救护，而且在艺人倒下的第一时间不进行救助竟然还在进行拍摄。一个户外大型竞技节目组安全意识竟然如此薄弱？！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     西瓜加鸭脖
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     首先需要真相呈现在大众面前，该追责追责，该承担责任承担责任，行业问题也好，制度问题也罢，解决眼前事，不姑息，不掩盖，才是娱乐产业走向光明的第一步，一条人命就这样逝去，究竟有没有按时抢救，我们需要真实的时间线，节目组的安全措施如何设置，我们需要完整的责任安全明细报告[/cp]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     梳格落笛
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@湖畔玫瑰:图片评论 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     甘愿来做gonglang
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     #追我吧本周停播# //@人民网:【传媒锐评：拒绝行业病态发展】高以翔意外身亡事件，暴露出的高强度吸睛、轻安全保障等真人秀综艺节目的行业性问题，到了需要审视反思的时候了。当制作方与明星陷入彼此需要又相互消耗的循环时，双方已无力打破畸形闭环，需要外力干预。传媒锐评：拒绝行业病态发展 让″高以翔们″放心飞翔
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     七墓凉公子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@wahgykr5yxjf:图片评论 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     梳格落笛
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     回复@敷尔佳吖-:图片评论 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     梳格落笛
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 4
     </li>
    </div>
    <p id="comment_content">
     回复@猫爪上的草履虫:图片评论 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     G日日是好日go
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 4
     </li>
    </div>
    <p id="comment_content">
     网曝高以翔父母安慰的是高以翔身边随行工作人员，并不是浙江台的工作人员！！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     一碗Absinthe
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 12
     </li>
    </div>
    <p id="comment_content">
     请浙江卫视给我们一个交代 评论配图
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     逆流而上的鱼和水滴
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     up！！！！！要让其他人也看到这条消息！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     叶小小91872
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@wahgykr5yxjf:上去
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     杉山而川
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     蓝台必须出来道歉！救援不到位！！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>