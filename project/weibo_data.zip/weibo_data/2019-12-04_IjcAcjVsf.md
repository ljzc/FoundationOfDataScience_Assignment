<html>
 <body>
  <h1 id="title">
   #美国祸港NGO大起底##美国祸港NGO大起底#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-04
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjcAcjVsf">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 127
   </li>
   <li id_no="comment_number">
    评论数量： 152
   </li>
   <li id_no="attitude">
    赞： 893
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【被中国点名制裁！#美国祸港NGO大起底#】2日，外交部宣布中方将对“美国国家民主基金会”“美国国际事务民主协会”等在香港修例风波中表现恶劣的非政府组织实施制裁
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     大量事实和证据表明，上述非政府组织在香港修例风波中，极力教唆反中乱港分子从事极端暴力活动，对香港乱局负有重大责任。（人民网国际频道）被中国点名制裁！美国祸港NGO大起底
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     人间欢
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 75
     </li>
    </div>
    <p id="comment_content">
     制裁美国，就像扫黑除恶
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     林有有的八字眉
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 43
     </li>
    </div>
    <p id="comment_content">
     美国必定亡国灭种
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     尼奇窝窝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 31
     </li>
    </div>
    <p id="comment_content">
     我宿舍全体表决，提供把“美国国家民主基金会”“美国国际事务民主协会”列入极端组织名单，并立刻生效制裁
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-04-08
    </p>
    <p id="comment_author">
     林信好-
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     疫情过后，国际社会会不会联合制裁中国？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-04-03
    </p>
    <p id="comment_author">
     夏了茶靡linger
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@你猜我在哪201902:一直是小人，不过是现在才明着来罢了。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-09
    </p>
    <p id="comment_author">
     sunny_y2014
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@KevinWu2020:非政府组织不也是政府组织买单吗？对吧！这叫杀鸡儆猴
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>