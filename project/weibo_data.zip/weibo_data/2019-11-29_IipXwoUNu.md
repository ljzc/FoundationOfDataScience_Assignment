<html>
 <body>
  <h1 id="title">
   #大二女生投30万开鸭咖##大二女生投30万开鸭咖#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-11-29
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IipXwoUNu">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 113
   </li>
   <li id_no="comment_number">
    评论数量： 272
   </li>
   <li id_no="attitude">
    赞： 1629
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【撸鸭使我快落！#大二女生投30万开鸭咖# 到店需提前预约】西安美术学院附近有一家咖啡店，店里有4只鸭子和2只小香猪
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     在这里品尝饮品的同时，还可以撸鸭、撸猪，店老板是两位大二女生。她们说开店之前，两个人都是“好吃懒做”的大小姐，现在伺候鸭和猪一点都不含糊。@梨视频 一手video的秒拍视频
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     洪相散人
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 165
     </li>
    </div>
    <p id="comment_content">
     我还是喜欢它烤的外焦里嫩的样子
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     神奇知识点
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 284
     </li>
    </div>
    <p id="comment_content">
     我缺的是30w开店
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     口嗨馆
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 128
     </li>
    </div>
    <p id="comment_content">
     名副其实的鸭店
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-23
    </p>
    <p id="comment_author">
     乌青文文
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     @M-CHENG- 鸭店鸭
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-18
    </p>
    <p id="comment_author">
     七颗小馒头o
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@彡MINIDEAR:哈哈哈哈哈哈看看就好...看看就好！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-18
    </p>
    <p id="comment_author">
     彡MINIDEAR
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@Milky7nn:害怕猫狗不害怕猪鸭吗
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>