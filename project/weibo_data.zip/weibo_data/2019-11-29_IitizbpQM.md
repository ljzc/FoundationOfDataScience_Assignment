<html>
 <body>
  <h1 id="title">
   组图共9张组图共9张
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-11-29
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IitizbpQM">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 1079
   </li>
   <li id_no="comment_number">
    评论数量： 3697
   </li>
   <li id_no="attitude">
    赞： 126699
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :热播和待播的古装剧里，你最期待？              [
    </strong>
   </p>
   <div id="main_text">
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     夏天永远属于你
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 7466
     </li>
    </div>
    <p id="comment_content">
     三生三世枕上书 http://t.cn/AigahzQc
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     可可布朗尼0v0
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 6895
     </li>
    </div>
    <p id="comment_content">
     三生三世枕上书 http://t.cn/AigahZW1
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     Tang墨镜
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 6496
     </li>
    </div>
    <p id="comment_content">
     迪丽热巴三生三世枕上书
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-05-01
    </p>
    <p id="comment_author">
     荔安薇
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@dd88的帅气女友:飞
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-01-12
    </p>
    <p id="comment_author">
     叫青哥
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     两世欢❤两世欢❤两世欢❤两世欢❤两世欢❤两世欢❤两世欢❤两世欢❤两世欢❤两世欢❤两世欢❤两世欢❤两世欢❤两世欢❤两世欢❤两世欢❤
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>