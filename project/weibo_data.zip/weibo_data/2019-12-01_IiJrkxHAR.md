<html>
 <body>
  <h1 id="title">
   #内蒙古自治区政协副主席接受审查调查##内蒙古自治区政协副主席接受审查调查#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-01
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IiJrkxHAR">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 41
   </li>
   <li id_no="comment_number">
    评论数量： 51
   </li>
   <li id_no="attitude">
    赞： 266
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【#内蒙古自治区政协副主席接受审查调查#】内蒙古自治区政协副主席马明涉嫌严重违纪违法，目前正接受中央纪委国家监委纪律审查和监察调查
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     （中央纪委国家监委网站）内蒙古自治区政协副主席马明接受中央纪委国家监委审查调查
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
  </div>
 </body>
</html>