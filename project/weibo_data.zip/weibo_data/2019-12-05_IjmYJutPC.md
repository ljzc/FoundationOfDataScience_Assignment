<html>
 <body>
  <h1 id="title">
   #聚焦营商环境##聚焦营商环境#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-05
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjmYJutPC">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 41
   </li>
   <li id_no="comment_number">
    评论数量： 96
   </li>
   <li id_no="attitude">
    赞： 278
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【#聚焦营商环境#：官方承认的欠款，为啥7年要不来?】宁夏银川：活干完数年，工程款仍一分未见；河南漯河：层层过审的项目突然易主，企业千万资金打水漂…两笔7年都结不了的账卡哪了？官方承诺咋成“空头支票”？宁夏、河南两家民企的讨债之路何时到终点？（人民网网连中国）网连中国――两笔7年都结不了的账（聚焦营商环境）              [
    </strong>
   </p>
   <div id="main_text">
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     深海作别_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 29
     </li>
    </div>
    <p id="comment_content">
     上了人民网，马上就能要回来了！～
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     91-老赖
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 19
     </li>
    </div>
    <p id="comment_content">
     关键是没钱，地方债难解
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     夜生生物
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 5
     </li>
    </div>
    <p id="comment_content">
     算上利息
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-18
    </p>
    <p id="comment_author">
     chaumian
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     地方债的问题只能靠感知，没有途径看到真纹理
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-09
    </p>
    <p id="comment_author">
     小事儿xiao4r
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     转发微博
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>