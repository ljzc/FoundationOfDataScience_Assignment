<html>
 <body>
  <h1 id="title">
   @人民日报@人民日报
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-04
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjfAZfrEo">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 124
   </li>
   <li id_no="comment_number">
    评论数量： 165
   </li>
   <li id_no="attitude">
    赞： 975
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【中国用美国的钱变强大？华春莹称美重建中国的说法太可笑】12月4日，外交部发言人华春莹主持召开外交部例行记者会，有记者提问称，有美国领导人近日称，中国已非常强大，这很大程度上是利用美国的钱做到的
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     中方对此有何评论？华春莹表示，这个说法太可笑了！环顾全球，这个世界上有哪个国家有能力用钱来重建一个中国？太可笑了！中国发展的成就可不是从天上掉下来的，也不是靠什么人、什么国家恩赐施舍的，而是全体中国人民用自己的勤劳、汗水、智慧和勇气干出来的。这一点如果有人还没有看清楚，我只能说真是太缺乏教育了。我想指出的是，自从1987年中国有外资统计以来，中国累计实际使用外资2万多亿美元，其中美国对华投资800多亿美元，仅占中国吸引外国投资的4%左右，仅仅是这个比例而已。但是我们都知道美国从中美合作当中获得了多大的收益。有多少美国家庭因为中国商品而大幅降低了生活成本？美国企业更是获得了丰厚利润。97%的美国受访企业表示跟中国做生意是盈利的。根据美中贸易全国委员会的报告，仅仅美国对华出口一项就支撑了超过110万个美国就业岗位。而在2017年，通用集团在全球亏损110亿元人民币的情况下，从其在中国的两家合资企业拿走的利润将近134亿元！而高通在华销售额占到了总营业收入的58%。也就是说中国养活了、养肥了多少美国企业？！这笔账，我希望他们好好算一算。@人民日报
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     猫片bot
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 59
     </li>
    </div>
    <p id="comment_content">
     自己都没脸了，还往自己脸上贴金
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     走下去就是了
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 45
     </li>
    </div>
    <p id="comment_content">
     中国的强大是利用WTO的规则强大的，是无数农民工背井离乡强大的，是13亿人民自强不息强大的，是没有殖民没有掠夺的强大，中国强大，何错之有？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     森婶儿琳小琳
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     实在不行就抛美债吧
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     远道无邪
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     全球化进程中的无脑对喷
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     镜夜水花梦离
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这玩意也太不要脸了，我们是债权国，被迫人民币贬值，谁用谁的钱了？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>