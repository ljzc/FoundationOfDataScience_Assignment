<html>
 <body>
  <h1 id="title">
   #电力小哥扛梯狂奔救落水男童##电力小哥扛梯狂奔救落水男童#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-05
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjlTIALja">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 62
   </li>
   <li id_no="comment_number">
    评论数量： 61
   </li>
   <li id_no="attitude">
    赞： 674
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【好样的！#电力小哥扛梯狂奔救落水男童#】近日，江苏东海县，一名孩童在商业街环城河意外落水
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     在附近完成电力运维工作的张演瑞、路兴晨听到呼救声，扛起梯子一路狂奔，最终将孩子救起。为电力小哥点赞！你飞奔的样子帅呆啦！
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     烊烊AD钙奶
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 15
     </li>
    </div>
    <p id="comment_content">
     为小哥点赞
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     玺礼
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 7
     </li>
    </div>
    <p id="comment_content">
     正能量 点赞👍
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     小嘎嘎_0716
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     点赞小哥！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     失落城里失落人
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     是该建围栏了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     虾米90958
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     好棒！为小哥点赞
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     單身萬歲19861113
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     这河紧挨路边应该加个护栏
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>