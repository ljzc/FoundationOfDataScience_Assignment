<html>
 <body>
  <h1 id="title">
   #万能的消防员##万能的消防员#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-06
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjuJIeVbD">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 61
   </li>
   <li id_no="comment_number">
    评论数量： 192
   </li>
   <li id_no="attitude">
    赞： 1242
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【学生宿舍吃着火锅烫头发，#万能的消防员#顺着网线就来了】近日，江西南昌某高校男生在寝室吃着火锅染头发，将视频发布社交平台后遭网友举报，消防员一小时内爬网线找到该寝室，搜出违规电器
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     学校学工处老师称已将吃火锅的那个锅收走。
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-06
    </p>
    <p id="comment_author">
     请问你是哪位小朋友
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 233
     </li>
    </div>
    <p id="comment_content">
     哈哈哈哈原来顺着网线来打我呀是有道理的
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-06
    </p>
    <p id="comment_author">
     那些细思极恐的事
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 120
     </li>
    </div>
    <p id="comment_content">
     我就说吧消防员是万能的。。。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-06
    </p>
    <p id="comment_author">
     那些细思极恐的事
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 79
     </li>
    </div>
    <p id="comment_content">
     这是在网上下载了个消防员吗
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-10
    </p>
    <p id="comment_author">
     三三小盆友_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     好了，毕业证没了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-10
    </p>
    <p id="comment_author">
     幼稚园的彩虹糖
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@脆皮镜Mirror37:哈哈哈哈，牛皮
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>