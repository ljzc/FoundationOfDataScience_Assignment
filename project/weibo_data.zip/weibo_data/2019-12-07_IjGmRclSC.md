<html>
 <body>
  <h1 id="title">
   #武大靖500米决赛摘银##武大靖500米决赛摘银#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-07
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjGmRclSC">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 1769
   </li>
   <li id_no="comment_number">
    评论数量： 2472
   </li>
   <li id_no="attitude">
    赞： 49357
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【意外重重！#武大靖500米决赛摘银#】短道速滑世界杯男子500米决赛意外重重，先是两位选手摔出冰面，中国选手武大靖被踢到
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     随后在超越过程中选手间发生碰撞，#武大靖摔倒#。最终，刘少林夺得冠军，武大靖摘银，刘少昂排在第三。希望选手们没有大碍！@央视体育 央视体育的微博视频
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-07
    </p>
    <p id="comment_author">
     团子做的糯米
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 3911
     </li>
    </div>
    <p id="comment_content">
     差点以为前三都是中国人
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-07
    </p>
    <p id="comment_author">
     甜味拾荒__
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 2662
     </li>
    </div>
    <p id="comment_content">
     在激烈比赛节奏下 要注意身体健康哟
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-07
    </p>
    <p id="comment_author">
     开拖拉机去偷月亮的人儿
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 2463
     </li>
    </div>
    <p id="comment_content">
     安全第一，人没事就好，银牌也很厉害了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-02-21
    </p>
    <p id="comment_author">
     易千哲
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     大靖安全最重要，要养好身体才行
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-02-16
    </p>
    <p id="comment_author">
     满天星要blingbling
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     现在在看荷兰站的比赛，看到刚才大靖500被影响，想到上海站他受伤，就过来再看下，真的好想哭啊，好心疼他啊
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>