<html>
 <body>
  <h1 id="title">
   #香港是中国的香港##香港是中国的香港#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-11-28
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IigRLuJJn">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 77
   </li>
   <li id_no="comment_number">
    评论数量： 128
   </li>
   <li id_no="attitude">
    赞： 488
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :#香港是中国的香港# 【国务院港澳办发表声明强烈谴责美方将“香港人权与民主法案”签署成法】国务院港澳事务办公室11月28日发表声明，对美方将“香港人权与民主法案”签署成法表示强烈谴责
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     #香港事务是中国的内政#　　该声明表示，当地时间11月27日，美方不顾中方的强烈反对，一意孤行，将“香港人权与民主法案”签署成法。这是对中国内政赤裸裸的干涉，是对国际法和国际关系基本准则的严重践踏。这部遭到包括香港同胞在内的全中国人民声讨的法案充斥着偏见和傲慢，以恐吓和威胁的手法对待香港，公然为反中乱港分子提供保护，用心险恶。事实证明，美方就是搞乱香港的最大黑手。　　该声明指出，中国政府维护国家主权、安全、发展利益的决心坚定不移，贯彻“一国两制”方针的决心坚定不移，反对任何外部势力干涉香港事务的决心坚定不移。美方想借搞乱香港遏制中国发展，是枉费心机，打错了算盘。香港的前途和命运始终掌握在包括香港同胞在内的中国人民手中，没有任何力量能够阻挡中华民族实现伟大复兴的步伐。http://t.cn/AigtAomy
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-28
    </p>
    <p id="comment_author">
     a--不懂
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 15
     </li>
    </div>
    <p id="comment_content">
     中国的内政不容干涉！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-28
    </p>
    <p id="comment_author">
     迷失regret
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 16
     </li>
    </div>
    <p id="comment_content">
     谴责不行就强烈谴责 强烈谴责不行就强烈谴责！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     zhl双鱼座海阔天空
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@-付靖靖- 的表态:谢谢！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-29
    </p>
    <p id="comment_author">
     格林我抬头仰望星空2002
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     美国算老几，也不撒泡尿照照自己
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-28
    </p>
    <p id="comment_author">
     风遮墨竹
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     谴责，谴责就好！谴责谴责，就好了！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>