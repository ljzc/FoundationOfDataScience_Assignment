<html>
 <body>
  <h1 id="title">
   #云南安石隧道事故致12人遇难##云南安石隧道事故致12人遇难#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-04
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjfUlzrIg">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 74
   </li>
   <li id_no="comment_number">
    评论数量： 124
   </li>
   <li id_no="attitude">
    赞： 292
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【默哀！#云南安石隧道事故致12人遇难#】11月26日，云南安石隧道出口发生突泥涌水灾害
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     至12月4日，现场救援工作已结束，此次灾害共造成12人遇难、10人受伤(含前期自救和被解救9人)。目前，工作重点已转入善后收尾阶段，同时积极配合有关部门开展灾害原因调查。(人民网云南频道)云南临沧隧道突泥涌水事故救援结束 致12人遇难
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     公考指南Afun
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 24
     </li>
    </div>
    <p id="comment_content">
     面对天灾人祸，首先应该妥善做好应急处置工作，让伤痛和损失降到最低。与此同时，还应悔于已然、防患未然，从源头着手优化相关法律法规、制定相应的应急预案、收集信息形成预警机制。真正做到亡羊补牢、犹未晚也，从而有效减少类似事件的发生才是正解
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     一只猪蹄丶
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 9
     </li>
    </div>
    <p id="comment_content">
     逝者安息🙏🙏年底了大家都平平安安的啊
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     樱了个小丸子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     🙏🏻🙏🏻注意安全
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     理智的旁观者
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     飞翔的小月半月半
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 1
     </li>
    </div>
    <p id="comment_content">
     这个月怎么天天出事情
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>