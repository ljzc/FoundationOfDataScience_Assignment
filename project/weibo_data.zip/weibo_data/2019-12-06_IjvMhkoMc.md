<html>
 <body>
  <h1 id="title">
   @新华视点@新华视点
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-06
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjvMhkoMc">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 40
   </li>
   <li id_no="comment_number">
    评论数量： 45
   </li>
   <li id_no="attitude">
    赞： 218
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【国务院关税税则委员会开展部分大豆、猪肉等自美采购商品的排除工作】根据国内需要，我国企业自主通过市场化采购，自美进口一定数量商品
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     国务院关税税则委员会正在根据相关企业的申请，开展部分大豆、猪肉等商品排除工作，对排除范围内商品，采取不加征我对美301措施反制关税等排除措施。对排除范围内商品采购，企业自主商谈、自行进口、自负盈亏。@新华视点
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
  </div>
 </body>
</html>