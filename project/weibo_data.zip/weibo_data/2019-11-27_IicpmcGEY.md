<html>
 <body>
  <h1 id="title">
   #摔倒后立刻爬起关停电梯##摔倒后立刻爬起关停电梯#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-11-27
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IicpmcGEY">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 448
   </li>
   <li id_no="comment_number">
    评论数量： 152
   </li>
   <li id_no="attitude">
    赞： 2468
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     【多亏有你！为救乘客 地铁志愿者#摔倒后立刻爬起关停电梯#】11月24日，湖北武汉，一名50岁左右的中年男子，乘地铁电扶梯时因正在接电话，身体没站稳摔倒
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     地铁志愿者看到后飞奔跑下来，虽中途摔倒但立刻爬起及时关停电梯，志愿者膝盖擦伤。小伙子好样的！
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-27
    </p>
    <p id="comment_author">
     吾家有儿初长成眉眼如画温如言
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 50
     </li>
    </div>
    <p id="comment_content">
     太帅了，这才是帅！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-27
    </p>
    <p id="comment_author">
     你指不定哪有猫饼
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 36
     </li>
    </div>
    <p id="comment_content">
     他摔倒了又立刻爬起来关开关的样子真正诠释了“奋不顾身”四个字
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-27
    </p>
    <p id="comment_author">
     所遇皆是命
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 32
     </li>
    </div>
    <p id="comment_content">
     少年强，则国强，为少年点赞
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-28
    </p>
    <p id="comment_author">
     个子高不洗澡
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-28
    </p>
    <p id="comment_author">
     空悲欢521zlf
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     、
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-28
    </p>
    <p id="comment_author">
     空悲欢521zlf
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>