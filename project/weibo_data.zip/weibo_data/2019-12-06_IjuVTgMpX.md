<html>
 <body>
  <h1 id="title">
   #大爷大妈在公园爬行健身##大爷大妈在公园爬行健身#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-06
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjuVTgMpX">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 57
   </li>
   <li id_no="comment_number">
    评论数量： 217
   </li>
   <li id_no="attitude">
    赞： 585
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【#大爷大妈在公园爬行健身#：效果好能治病】12月3日，河南郑州
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     多名老人在公园手脚着地，缓慢爬行。一位大爷称在模仿动物爬行健身，可治疗多种疾病。据悉，这种健身方式在郑州公园内已流行多年。专家提醒：并不是所有人都适用这种健身方式。
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
  </div>
 </body>
</html>