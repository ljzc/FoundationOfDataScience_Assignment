<html>
 <body>
  <h1 id="title">
   #香港是中国的香港##香港是中国的香港#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-11-28
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IigCsFujI">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 177
   </li>
   <li id_no="comment_number">
    评论数量： 232
   </li>
   <li id_no="attitude">
    赞： 797
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :#香港是中国的香港# 【外交部就美方将所谓“香港人权与民主法案”签署成法发表声明】外交部28日就美方将所谓“香港人权与民主法案”签署成法发表声明，全文如下：       美方将所谓“香港人权与民主法案”签署成法，此举严重干预香港事务，严重干涉中国内政，严重违反国际法和国际关系基本准则，是赤裸裸的霸权行径，中国政府和人民坚决反对
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     香港回归祖国以来，“一国两制”取得举世公认的成功，香港居民依法享有前所未有的民主权利。美方罔顾事实、颠倒黑白，公然为疯狂打砸烧、残害无辜市民、践踏法治、危害社会秩序的暴力犯罪分子撑腰打气，性质极其恶劣，用心十分险恶，其根本目的是破坏香港繁荣稳定，破坏“一国两制”伟大实践，破坏中华民族实现伟大复兴的历史进程。　　我们要正告美方，香港是中国的香港，香港事务纯属中国内政，任何外国政府和势力都无权干预。这一所谓法案只会让包括香港同胞在内的广大中国人民进一步认清美国的险恶用心和霸权本质，只会让中国人民更加众志成城。美方的图谋注定失败。　　中国政府反对任何外部势力干预香港事务的决心坚定不移，贯彻“一国两制”方针的决心坚定不移，维护国家主权、安全、发展利益的决心坚定不移。我们奉劝美方不要一意孤行，否则中方必将予以坚决反制，由此产生的一切后果必须由美方承担。http://t.cn/Aig51ASH
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
  </div>
 </body>
</html>