<html>
 <body>
  <h1 id="title">
   #高校男生模仿给妈妈洗脚广告片##高校男生模仿给妈妈洗脚广告片#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-06
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/Ijulmhvyr">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 86
   </li>
   <li id_no="comment_number">
    评论数量： 170
   </li>
   <li id_no="attitude">
    赞： 1141
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【#高校男生模仿给妈妈洗脚广告片#：视频沙雕但生活正常】4日，河南省信阳学院一宿舍男生模仿广告片段火了
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     视频创作者19级物联网闵同学说：平时为了活跃宿舍的气氛，纪念大学生活。虽然视频沙雕，但是生活中是啥样还是啥样。@封面新闻 青蕉视频的微博视频
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-06
    </p>
    <p id="comment_author">
     王子的小玫瑰哦
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 235
     </li>
    </div>
    <p id="comment_content">
     不怕沙雕多，就怕沙雕凑一窝
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-06
    </p>
    <p id="comment_author">
     尼奇窝窝
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 64
     </li>
    </div>
    <p id="comment_content">
     过年回家好好给你妈洗个吧
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-06
    </p>
    <p id="comment_author">
     小嘎嘎_0716
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 43
     </li>
    </div>
    <p id="comment_content">
     生活需要一些正能量的事情！这种又沙雕又正能量的事情真的很好！我相信这个男生心里肯定是想着妈妈才会拍出这么暖心的沙雕视频的。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-20
    </p>
    <p id="comment_author">
     小神158
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     @赫本同学_Audrey
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-07
    </p>
    <p id="comment_author">
     深海和她
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@王子的小玫瑰哦:哈哈哈哈哈，我们一女宿舍三人
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>