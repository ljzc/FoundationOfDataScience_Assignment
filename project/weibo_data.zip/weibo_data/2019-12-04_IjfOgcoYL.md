<html>
 <body>
  <h1 id="title">
   #过安检顺走安检员的手机##过安检顺走安检员的手机#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-04
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjfOgcoYL">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 39
   </li>
   <li id_no="comment_number">
    评论数量： 138
   </li>
   <li id_no="attitude">
    赞： 627
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【男子#过安检顺走安检员的手机# 民警在列车上将其抓回】近日，一男子在天津站过安检时，看到安检员的手机掉落，男子立刻装进自己包里，随后乘列车离开
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     安检员报警后，天津站民警联系石家庄站民警上车将其抓回。目前，该男子涉嫌盗窃罪被刑事拘留。@时间视频 北京时间直播的秒拍视频
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     雾似书中人
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 101
     </li>
    </div>
    <p id="comment_content">
     这男的也真是……
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     公考指南Afun
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 44
     </li>
    </div>
    <p id="comment_content">
     贼:我太难了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-15
    </p>
    <p id="comment_author">
     潘家三番
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     不是自己的东西不要拿
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-10
    </p>
    <p id="comment_author">
     超级天涯共此时987
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@笑经人生风雨路:[加油][加油][加油][加油][加油]
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-09
    </p>
    <p id="comment_author">
     林宇一起走1314
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@志学思言行:你试试啊，键盘侠。不是你的东西，你拿走了，还有理！喷子蛋
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>