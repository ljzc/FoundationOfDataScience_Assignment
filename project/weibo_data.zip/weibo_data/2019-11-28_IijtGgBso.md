<html>
 <body>
  <h1 id="title">
   #先有鸡还是先有蛋终于有答案##先有鸡还是先有蛋终于有答案#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-11-28
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IijtGgBso">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 231
   </li>
   <li id_no="comment_number">
    评论数量： 214
   </li>
   <li id_no="attitude">
    赞： 939
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【#先有鸡还是先有蛋终于有答案# 科学家：6.1亿年前就有“蛋”】中科院南京地质古生物研究所发现，6.1亿年前的贵州瓮安生物群中，保存了一类名叫笼脊球的化石
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     该化石的发现表明，类似动物胚胎的“蛋”6.1亿年前就已出现，而直到4000万年后，动物才在地球上大量出现。@现代快报 现代快报快快看视频的微博视频
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-28
    </p>
    <p id="comment_author">
     阿明不吃辣
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 115
     </li>
    </div>
    <p id="comment_content">
     那你怎么知道6.11亿年前没有鸡呢
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-28
    </p>
    <p id="comment_author">
     黑马奇
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 39
     </li>
    </div>
    <p id="comment_content">
     生出鸡蛋的不一定是鸡
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-28
    </p>
    <p id="comment_author">
     神奇知识点
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 33
     </li>
    </div>
    <p id="comment_content">
     蛋怎么来的？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-12-12
    </p>
    <p id="comment_author">
     亦如尘往
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     应该不止神经元的进化，促成神经元进化的是神经元的交流方式
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-12-12
    </p>
    <p id="comment_author">
     亦如尘往
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     回复@亦如尘往:即卵生生物向胚胎生物的再进化再次进化，多余能量促进了神经组织进化。 一部分能量的倒回使这份进化能量逆转了进化形式，组成了曾经断裂过或分裂过的基因链。 进化是在胚胎内完成的不是胚胎外，体外的异端进化就好像癌症，满足青蛙类的变态发育可不多见，一种满足能力形式的进化才是生物最本质的进化。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2020-12-12
    </p>
    <p id="comment_author">
     亦如尘往
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     蛋的存在起源于生物遗传因子的突变，应该说先有生物体，最满足最初细胞分裂本体特征，这种异端进化应当是最早出现于遗传因子的改变，而且这种遗传因子的改变是在体内完成的。（生物体内最早出现的是胚胎，蛋壳只是为了保护胚胎的存在而出现。） 海豚的高智商以及和人类的相似上，很可能存在逆进化，即
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>