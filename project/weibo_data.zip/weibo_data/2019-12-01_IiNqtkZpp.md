<html>
 <body>
  <h1 id="title">
   #人民网版垃圾分类disco##人民网版垃圾分类disco#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-01
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IiNqtkZpp">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 134
   </li>
   <li id_no="comment_number">
    评论数量： 66
   </li>
   <li id_no="attitude">
    赞： 270
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     【#人民网版垃圾分类disco#，太上头！】北京、郑州、成都等46城喜提垃圾分类重点城市
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     而《生活垃圾分类标志》标准，也于今天起正式实施。配图小编皮皮改编一首《垃圾分类disco》，带你分清可回收物、有害垃圾、厨余垃圾、其他垃圾！
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-01
    </p>
    <p id="comment_author">
     发刊物--联系我
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 21
     </li>
    </div>
    <p id="comment_content">
     嗯。。。。有个建议，垃圾分类以后是要长期实行的。那么在方便分类和让大家更容易记住一类垃圾的分类，可不可让生产报装啊，啥的厂家在包装上打上包装是什么类型的垃圾。这样久而久之大家也容易记住一类型的垃圾分类了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-01
    </p>
    <p id="comment_author">
     藍湛_十三载
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 2
     </li>
    </div>
    <p id="comment_content">
     学会垃圾分类，保护生态环境卫生
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-01
    </p>
    <p id="comment_author">
     泡杯红茶V
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 3
     </li>
    </div>
    <p id="comment_content">
     不分了。九月刚刚在我们西安执行的时候，我会分也分的相当熟练了，谁知才一个月功夫不到，小区的所有垃圾桶全部变成“其他垃圾桶”，分的再细致也没法倒了，所以还分个毛线！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     楼兰姑娘他爹
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     整的大家以后都是垃圾分类专家，每天啥也不干 研究怎么分类了。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     草上工蜂
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     垃圾分类好处多
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>