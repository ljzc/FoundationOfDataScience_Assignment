<html>
 <body>
  <h1 id="title">
   #救护车鸣笛74秒私家车未让行##救护车鸣笛74秒私家车未让行#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-05
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IjljCxlew">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 114
   </li>
   <li id_no="comment_number">
    评论数量： 485
   </li>
   <li id_no="attitude">
    赞： 2394
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【#救护车鸣笛74秒私家车未让行# 被罚款200扣3分】近日，湖北宜昌，一辆私家车等红灯时，一辆救护车在后方一直拉警报、鸣笛，长达74秒里，私家车车主未避让救护车
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     当阳警方通报称，救护车拉一名脚受伤的病人送医，私家车车主未采取避让措施，被罚款200扣3分。
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     南极洲熊猫
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 284
     </li>
    </div>
    <p id="comment_content">
     昨天刚看了一个新闻因为让行救护车申诉了很多次都失败的，建议放宽让行的处罚，只要让行就不应该在处罚了，否则条例模棱两可加上政策普及不到位很多人想让又不敢让。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     王小虎同学丶
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 277
     </li>
    </div>
    <p id="comment_content">
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-22
    </p>
    <p id="comment_author">
     一个赵尤苒哟
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     罚的太轻了。不避让下次直接罚款1万。拘留7天。看他们还装聋做哑不
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-17
    </p>
    <p id="comment_author">
     Weo今天也很开心哦
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     人命和六分，真的六分更宝贵吗？
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>