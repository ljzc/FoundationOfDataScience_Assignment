<html>
 <body>
  <h1 id="title">
   #厨师斥用坏枣熬汤完整视频##厨师斥用坏枣熬汤完整视频#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-02
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IiRUODPQy">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 672
   </li>
   <li id_no="comment_number">
    评论数量： 1010
   </li>
   <li id_no="attitude">
    赞： 6199
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【#厨师斥用坏枣熬汤完整视频#：系家长发现劣质食材与厨师起争执】“厨师怒斥校方用坏枣熬汤”的视频热传
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     家长公布完整视频，称厨师和园方是亲戚，此前该幼儿园因食材问题致学生呕吐腹泻，在家委会要求下，购货渠道从菜场改为超市，厨师认为超市的枣难煮熟，辱骂家长。@梨视频 一手video的秒拍视频
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     热心市民查先生
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 944
     </li>
    </div>
    <p id="comment_content">
     还真是剧情超级大反转。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     ShinHae_
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 399
     </li>
    </div>
    <p id="comment_content">
     现在的新闻都要让子弹飞一会啊，唏嘘。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-18
    </p>
    <p id="comment_author">
     谁还不是个90后
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 4
     </li>
    </div>
    <p id="comment_content">
     回复@热心市民查先生:反转你妹  厨师本来就没事 就是一群沙雕家长满嘴跑火车
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-16
    </p>
    <p id="comment_author">
     爱菲灵古德19129
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     妈的，各种媒体能不能搞清楚了再往外发啊？真是服了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>