<html>
 <body>
  <h1 id="title">
   #中方决定对美国有关非政府组织进行制裁##中方决定对美国有关非政府组织进行制裁#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-12-02
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IiUxszOQq">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 739
   </li>
   <li id_no="comment_number">
    评论数量： 472
   </li>
   <li id_no="attitude">
    赞： 3023
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【外交部：#中方决定对美国有关非政府组织进行制裁# 转，周知！】12月2日，外交部发言人华春莹宣布：日前，美方不顾中方坚决反对，执意将所谓“香港人权与民主法案”签署成法，这严重违反国际法和国际关系基本准则，严重干涉中国内政，中方已就此表明坚决态度
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     针对美方无理行为，中国政府决定自即日起暂停审批美军舰机赴港休整的申请，同时对“美国国家民主基金会”、“美国国际事务民主协会”、“美国国际共和研究所”、“人权观察”、“自由之家”等在香港修例风波中表现恶劣的非政府组织实施制裁。中方敦促美方纠正错误，停止任何插手香港事务、干涉中国内政的言行，中方将根据形势发展采取进一步必要行动，坚定捍卫香港稳定繁荣，坚定捍卫国家主权、安全、发展利益。@人民视频 人民视频的微博视频
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     人民网
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 125
     </li>
    </div>
    <p id="comment_content">
     【有理有据！外交部回应#中方决定对美国有关非政府组织进行制裁#原因】大量事实和证据表明，有关非政府组织通过各种方式支持反中乱港分子，极力教唆他们从事极端暴力犯罪行为，煽动“港独”分裂活动，对当前香港乱局负有重大责任。这些组织理应受到制裁，必须付出应有代价。
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-03
    </p>
    <p id="comment_author">
     人民网
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 31
     </li>
    </div>
    <p id="comment_content">
     【人民网评：是时候给美国一些人当头棒喝了！】非政府组织本是促进社会公益的民间组织，然而在美国一些人手中，这些机构干着挂羊头、卖狗肉的肮脏勾当。制裁这些扛着“人权”“民主”牌坊祸害各方的组织，大快人心！#香港是中国的香港#。美国这些人啊，机关算尽太聪明！呵呵！人民网评：是时候给美国一些人当头棒喝了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-02
    </p>
    <p id="comment_author">
     行走的穆天子
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 136
     </li>
    </div>
    <p id="comment_content">
     干得漂亮
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     老韩66666
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     👏 👏 👏 👏 👏
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-05
    </p>
    <p id="comment_author">
     老林6666666
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     👏👏👏👏👏👏
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>