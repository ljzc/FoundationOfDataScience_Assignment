<html>
 <body>
  <h1 id="title">
   #新消防员站岗站到腿僵##新消防员站岗站到腿僵#
  </h1>
  <div id="basic_info">
   <h2 id="default h2">
    基本信息：
   </h2>
   <p id="time">
    2019-11-30
   </p>
   <p id="author">
    人民网
   </p>
   <p id="src">
    <a href="https://weibo.cn/comment/IiEuCuljb">
     新闻链接
    </a>
   </p>
   <p id="is_rendered">
    渲染： False
   </p>
   <p id="location">
    地点： None
   </p>
   <p id="news_type">
    类型： central media
   </p>
  </div>
  <div id="attrs">
   <li id_no="repost">
    转发： 260
   </li>
   <li id_no="comment_number">
    评论数量： 349
   </li>
   <li id_no="attitude">
    赞： 5071
   </li>
   <li id_no="target">
    疫情相关： False
   </li>
  </div>
  <div id="article">
   <h2 id="default h2">
    新闻主体：
   </h2>
   <p id="lead">
    <strong>
     :【心疼！#新消防员站岗站到腿僵# 仍坚持完成换岗】29日，@山西消防 发布一段视频：新消防员站岗到双腿僵硬，但他顾不上放松，坚持完成换岗交接仪式
    </strong>
   </p>
   <div id="main_text">
    <p id="paragraph_1">
     网友：最可爱的人，辛苦了！
    </p>
   </div>
  </div>
  <div id="analyse_info">
   分析信息，还没想好
  </div>
  <div id="comments">
   <h2 id="default h2">
    评论：
   </h2>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     娱乐萌萌圈
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 131
     </li>
    </div>
    <p id="comment_content">
     换成我们，估计站一个小时不赖烦了，解放军🐮，就完了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     深夜芳心纵火犯
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 67
     </li>
    </div>
    <p id="comment_content">
     最可爱的人，你们辛苦了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-11-30
    </p>
    <p id="comment_author">
     兵哥哥爱民谣
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： True
     </li>
     <li id_no="attitude">
      赞： 45
     </li>
    </div>
    <p id="comment_content">
     看到曾经的我，致敬战友！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-15
    </p>
    <p id="comment_author">
     白府九少
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     辛苦了*^_^*，同志
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     一身叹息
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     仪式感还是要的//@朱定祎律师: 其实，现代科技监控下，真没必要这样，这些年轻人是我们的未来，要爱惜他们！
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
   <div id="comments_block">
    <p id="comment_time">
     2019-12-04
    </p>
    <p id="comment_author">
     永存的淡蓝--凋谢01426
    </p>
    <div id="comment_attrs">
     <li id_no="is_hot">
      是否热门： False
     </li>
     <li id_no="attitude">
      赞： 0
     </li>
    </div>
    <p id="comment_content">
     辛苦了
    </p>
    <div id="comment_analyse_info">
     用于分析的数据，还没想好
    </div>
   </div>
   <hr/>
  </div>
 </body>
</html>